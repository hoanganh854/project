# Northbridge Library Management System

A browser-based Library Management System with a Python HTTP server, browser UI, SQLite persistence, and separated presentation/business/data layers. Its design follows the supplied `Test2.html` reference: split bookshelf sign-in, blue/navy branding, role-aware workspace navigation, dashboard cards, tables, and reader portal. The frontend is served by Python and calls the existing SQLite business services.

## Run in a browser

Use Python 3.10 or later; runtime dependencies are from the standard library.

```powershell
python PythonApplication3.py
```

Visual Studio's startup project also launches the local web server and opens the default browser. The app is served only on this computer at `http://127.0.0.1:8765/`. Stop it with Ctrl+C in the terminal. The former Tkinter desktop entry point remains available with `python app.py`.

The SQLite database is created at `~/.northstar_library/library.db` on first launch. Demo accounts are seeded once:

| Role | Username | Password |
|---|---|---|
| Administrator | `admin` | `Admin123!` |
| Librarian | `librarian` | `Librarian123!` |
| Reader | `reader` | `Reader123!` |

These are demonstration credentials only. Change them before using real library data. The reader demo card is `R00000001`; the seeded copy barcode is `BC000001`.

## Browser workflows

- Secure sign-in, role-specific screens, logout, and password change; sessions expire after 30 minutes idle.
- Catalogue search, book and copy management, reader registration, and membership controls.
- Reader portal with personal loans, renewal, reservations, and fines.
- Atomic checkout and return, reservation queues, overdue/fine processing, payments, and receipt numbers.
- Administrator staff controls, lending settings, audit log, reports, and CSV export.

Email notifications are queued in the database but require an external mail provider for delivery. The browser server binds to loopback and uses an in-memory session store: this is for a local coursework demo, not production hosting or multi-host deployment. HTTPS, persistent session storage, scheduled backup, and deployment hardening must be added before network exposure. The server opens a browser automatically; if it does not, visit the local address above.

## Architecture

- `web/index.html`, `web/style.css`, `web/app.js`: browser interface and client actions.
- `web_app.py`: local HTTP API, role checks, and 30-minute idle sessions.
- `lms/services.py`: validation, authorization, circulation rules, reports, and transactional use cases.
- `lms/database.py`: SQLite schema, seed data, connection setup, and transaction boundary.
- `lms/security.py`: salted PBKDF2-HMAC-SHA256 password hashes.
- `lms/reports.py`: Excel workbook export for the desktop interface.
- `tests/test_services.py` and `tests/test_web_api.py`: business and HTTP API regression tests.

All database inputs use parameterized SQL. Checkout and return changes run in a single `BEGIN IMMEDIATE` transaction with a unique partial index preventing concurrent active loans for one copy. Web sessions use an HttpOnly, SameSite cookie and requests are restricted to the local origin.

## Tests

Install the test-only dependency and run the business and web API tests:

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q
```
