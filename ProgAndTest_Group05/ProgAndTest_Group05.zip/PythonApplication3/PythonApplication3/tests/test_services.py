from __future__ import annotations

import zipfile

import pytest

from lms.database import Database
from lms.reports import export_xlsx
from lms.services import LibraryError, LibraryService


@pytest.fixture

def system(tmp_path):
    database = Database(tmp_path / "test-library.db")
    database.initialize()
    service = LibraryService(database)
    admin = service.login("admin", "Admin123!")
    librarian = service.login("librarian", "Librarian123!")
    reader = service.login("reader", "Reader123!")
    return database, service, admin, librarian, reader


def test_catalog_search_and_sql_input_is_treated_as_data(system):
    _database, service, _admin, _librarian, _reader = system
    assert service.list_books("Clean Code")[0]["title"] == "Clean Code"
    assert service.list_books("%' OR 1=1 --") == []


def test_checkout_creates_loan_and_marks_copy_borrowed(system):
    _database, service, _admin, librarian, _reader = system
    loan = service.checkout(librarian, "R00000001", "BC000001")
    assert loan["title"] == "Clean Code"
    assert len(service.list_loans(status="BORROWED")) == 1
    assert service.list_books("Clean Code")[0]["available_copies"] == 0


def test_checkout_refuses_duplicate_copy_without_partial_loan(system):
    _database, service, _admin, librarian, _reader = system
    service.checkout(librarian, "R00000001", "BC000001")
    with pytest.raises(LibraryError, match="not available"):
        service.checkout(librarian, "R00000001", "BC000001")
    assert len(service.list_loans(status="BORROWED")) == 1


def test_reader_can_renew_own_loan(system):
    _database, service, _admin, librarian, reader = system
    loan = service.checkout(librarian, reader["card_number"], "BC000001")
    original_due = loan["due_date"]
    new_due = service.renew_loan(reader, loan["loan_id"])
    renewed = service.list_loans(reader_id=reader["reader_id"])[0]
    assert new_due > original_due
    assert renewed["renew_count"] == 1


def test_invalid_login_locks_account_after_five_attempts(system):
    _database, service, _admin, _librarian, _reader = system
    for _ in range(5):
        with pytest.raises(LibraryError):
            service.login("reader", "incorrect")
    connection = _database.connect()
    try:
        account = connection.execute("SELECT status,failed_attempts FROM account WHERE username='reader'").fetchone()
    finally:
        connection.close()
    assert account["status"] == "LOCKED"
    assert account["failed_attempts"] == 5


def test_return_with_reservation_holds_copy_and_queues_notice(system):
    _database, service, _admin, librarian, reader = system
    service.checkout(librarian, reader["card_number"], "BC000001")
    service.reserve_book(librarian, 1, reader["reader_id"])
    result = service.return_copy(librarian, "BC000001", "Good")
    assert result["copy_status"] == "RESERVED"
    hold = service.list_reservations(reader["reader_id"])[0]
    assert hold["status"] == "READY"
    connection = _database.connect()
    try:
        notice = connection.execute("SELECT message FROM notification WHERE reader_id=?", (reader["reader_id"],)).fetchone()
    finally:
        connection.close()
    assert "ready for pickup" in notice["message"]


def test_reader_cannot_renew_another_readers_loan(system):
    _database, service, _admin, librarian, reader = system
    loan = service.checkout(librarian, "R00000001", "BC000001")
    other_reader = dict(reader, reader_id=reader["reader_id"] + 100)
    with pytest.raises(LibraryError, match="own loans"):
        service.renew_loan(other_reader, loan["loan_id"])


def test_reader_cannot_edit_catalog(system):
    _database, service, _admin, _librarian, reader = system
    with pytest.raises(LibraryError, match="permission"):
        service.save_book(reader, {"isbn": "new", "title": "Not allowed"})


def test_reader_account_returns_only_the_authenticated_readers_data(system):
    _database, service, _admin, _librarian, reader = system
    account = service.reader_account(reader)
    assert account["profile"]["reader_id"] == reader["reader_id"]
    assert account["profile"]["card_number"] == "R00000001"
    with pytest.raises(LibraryError, match="permission"):
        service.reader_account(_admin)


def test_overdue_maintenance_calculates_configured_late_fine(system):
    database, service, _admin, librarian, _reader = system
    service.checkout(librarian, "R00000001", "BC000001")
    connection = database.connect()
    try:
        connection.execute("UPDATE loan SET due_date='2000-01-01'")
        connection.commit()
    finally:
        connection.close()
    result = service.run_daily_maintenance()
    assert result["overdue_loans"] == 1
    loan = service.list_loans()[0]
    assert loan["status"] == "OVERDUE"
    fine = service.list_fines(unpaid_only=True)[0]
    assert fine["amount"] > 0
    assert fine["reason"] == "LATE"


def test_admin_can_change_settings_but_librarian_cannot(system):
    _database, service, admin, librarian, _reader = system
    service.update_settings(admin, {"LOAN_DAYS": "21"})
    assert service.settings()["LOAN_DAYS"] == "21"
    with pytest.raises(LibraryError, match="permission"):
        service.update_settings(librarian, {"LOAN_DAYS": "28"})


def test_reports_generate_data_and_validate_date_range(system):
    _database, service, _admin, librarian, _reader = system
    service.checkout(librarian, "R00000001", "BC000001")
    titles = service.report("Most borrowed titles")
    inventory = service.report("Current inventory")
    assert titles[0]["title"] == "Clean Code"
    assert inventory[0]["barcode"] == "BC000001"
    with pytest.raises(LibraryError, match="YYYY-MM-DD"):
        service.report("Books borrowed per period", "not-a-date", "")
    with pytest.raises(LibraryError, match="after the end date"):
        service.report("Books borrowed per period", "2025-02-01", "2025-01-01")


def test_xlsx_export_contains_workbook_and_report_rows(tmp_path):
    path = tmp_path / "report.xlsx"
    export_xlsx(path, [{"title": "Clean & Safe", "copies": 2}], ["title", "copies"])
    assert zipfile.is_zipfile(path)
    with zipfile.ZipFile(path) as workbook:
        assert "xl/workbook.xml" in workbook.namelist()
        assert "xl/worksheets/sheet1.xml" in workbook.namelist()
        sheet = workbook.read("xl/worksheets/sheet1.xml").decode("utf-8")
    assert "Clean &amp; Safe" in sheet
    assert ">2<" in sheet
