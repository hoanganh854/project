from __future__ import annotations

import json
import threading
from http.cookiejar import CookieJar
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, Request, build_opener

import pytest

from lms.database import Database
from lms.services import LibraryService
from web_app import LibraryHTTPServer


@pytest.fixture

def web_server(tmp_path):
    database = Database(tmp_path / "web-library.db")
    database.initialize()
    server = LibraryHTTPServer(("127.0.0.1", 0), LibraryService(database))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}", server
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


def request_json(opener, url, method="GET", body=None):
    headers = {"X-Requested-With": "NorthbridgeLibrary"}
    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")
    request = Request(url, data=data, headers=headers, method=method)
    try:
        with opener.open(request, timeout=3) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except HTTPError as response:
        return response.code, json.loads(response.read().decode("utf-8"))


def test_browser_entry_and_assets_are_served(web_server):
    base, _server = web_server
    opener = build_opener()
    with opener.open(base + "/", timeout=3) as response:
        html = response.read().decode("utf-8")
    with opener.open(base + "/app.js", timeout=3) as response:
        javascript = response.read().decode("utf-8")
    with opener.open(base + "/style.css", timeout=3) as response:
        stylesheet = response.read().decode("utf-8")
    assert "Northbridge Public Library" in html
    assert "function renderLogin" in javascript
    assert ".login-hero" in stylesheet


def test_librarian_login_and_catalogue_api(web_server):
    base, _server = web_server
    opener = build_opener(HTTPCookieProcessor(CookieJar()))
    status, actor = request_json(opener, base + "/api/login", "POST", {"username": "librarian", "password": "Librarian123!"})
    assert status == 200
    assert actor["role"] == "LIBRARIAN"
    status, books = request_json(opener, base + "/api/books?q=Clean%20Code")
    assert status == 200
    assert books[0]["title"] == "Clean Code"
    status, dashboard = request_json(opener, base + "/api/dashboard")
    assert status == 200
    assert dashboard["inventory"] == 1


def test_role_restrictions_and_reader_data_privacy(web_server):
    base, _server = web_server
    anonymous = build_opener()
    status, _response = request_json(anonymous, base + "/api/dashboard")
    assert status == 401

    librarian = build_opener(HTTPCookieProcessor(CookieJar()))
    request_json(librarian, base + "/api/login", "POST", {"username": "librarian", "password": "Librarian123!"})
    status, _response = request_json(librarian, base + "/api/settings")
    assert status == 403

    reader = build_opener(HTTPCookieProcessor(CookieJar()))
    request_json(reader, base + "/api/login", "POST", {"username": "reader", "password": "Reader123!"})
    status, account = request_json(reader, base + "/api/me")
    assert status == 200
    assert account["account"]["profile"]["card_number"] == "R00000001"
    status, _response = request_json(reader, base + "/api/dashboard")
    assert status == 403


def test_login_rejects_bad_credentials_and_cross_origin_posts(web_server):
    base, _server = web_server
    opener = build_opener(HTTPCookieProcessor(CookieJar()))
    status, _response = request_json(opener, base + "/api/login", "POST", {"username": "librarian", "password": "wrong"})
    assert status == 401
    request = Request(base + "/api/login", data=b'{"username":"reader","password":"Reader123!"}',
                      headers={"Content-Type": "application/json", "Origin": "http://attacker.invalid",
                               "X-Requested-With": "NorthbridgeLibrary"}, method="POST")
    with pytest.raises(HTTPError) as error:
        opener.open(request, timeout=3)
    assert error.value.code == 403
