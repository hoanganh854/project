"""Visual Studio startup entry point for the browser-based library system."""

from web_app import main


if __name__ == "__main__":
    main()
