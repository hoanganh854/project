"""Application entry point."""

from pathlib import Path
import tkinter as tk

from lms.database import Database
from lms.services import LibraryService
from lms.ui import LibraryApp


def main() -> None:
    data_dir = Path.home() / ".northstar_library"
    database = Database(data_dir / "library.db")
    database.initialize()
    root = tk.Tk()
    LibraryApp(root, LibraryService(database))
    root.mainloop()


if __name__ == "__main__":
    main()
