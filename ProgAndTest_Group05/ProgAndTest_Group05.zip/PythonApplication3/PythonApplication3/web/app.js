"use strict";

const root = document.querySelector("#root");
const modal = document.querySelector("#modal");
const toast = document.querySelector("#toast");
const state = { actor: null, page: "Dashboard", books: [], readers: [], selectedBook: null, selectedReader: null, selectedLoan: null, selectedReservation: null, selectedFine: null, reportRows: [] };
const NAV = [
  ["Dashboard", "📊"], ["Book search", "🔍"], ["Books", "📚"], ["Readers", "👥"],
  ["Borrow book", "📤"], ["Return book", "📥"], ["Reservations", "🔖"], ["Fines", "💳"],
  ["Reports", "📈"], ["Staff & settings", "⚙"], ["Audit log", "🕒"], ["My account", "👤"]
];
const TITLES = {
  Dashboard: ["Dashboard", "Service desk overview and today's circulation."],
  "Book search": ["Book search", "Discover titles across the Northbridge collection."],
  Books: ["Book management", "Manage book titles and their physical copies."],
  Readers: ["Reader management", "Manage reader records and membership cards."],
  "Borrow book": ["Borrow book", "Validate the reader and check out an available copy."],
  "Return book": ["Return book", "Record the book condition and calculate any late fine."],
  Reservations: ["Reservations", "Review holds and the waiting queue."],
  Fines: ["Fines", "Review balances, record payments, and issue receipts."],
  Reports: ["Reports", "Generate circulation, inventory, reader, and revenue reports."],
  "Staff & settings": ["Accounts & settings", "Manage staff access and library parameters."],
  "Audit log": ["Activity log", "Review recorded changes and circulation activity."],
  "My account": ["My account", "Review your own loans, holds, and fines."]
};

const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const money = (value) => `${Number(value || 0).toLocaleString()} VND`;
const roleName = (role) => ({ ADMIN: "Administrator", LIBRARIAN: "Librarian", READER: "Reader", GUEST: "Guest" })[role] || role;
const canStaff = () => ["LIBRARIAN", "ADMIN"].includes(state.actor?.role);
const isAdmin = () => state.actor?.role === "ADMIN";

async function api(path, options = {}) {
  const headers = { "X-Requested-With": "NorthbridgeLibrary", ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) };
  const response = await fetch(path, { credentials: "same-origin", ...options, headers });
  const payload = response.status === 204 ? null : await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && !path.endsWith("/login")) {
      state.actor = null;
      renderLogin();
    }
    throw new Error(payload?.error || `Request failed (${response.status}).`);
  }
  return payload;
}

function notify(message, error = false) {
  toast.textContent = message;
  toast.style.borderLeftColor = error ? "#c94a4a" : "#f2a93b";
  toast.classList.add("show");
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove("show"), 3000);
}

function run(action) {
  return Promise.resolve().then(action).catch((error) => notify(error.message, true));
}

function renderLogin() {
  state.actor = null;
  root.innerHTML = `
    <section class="login">
      <div class="login-hero" aria-hidden="true">
        <div class="hero-copy"><div class="bookmark">📚</div><h2>A world of stories,</h2><p>waiting to be found.</p></div>
        <div class="shelf">${Array.from({ length: 11 }, (_, i) => `<i class="spine spine-${i + 1}"></i>`).join("")}</div>
      </div>
      <div class="login-pane"><form class="login-card" id="loginForm">
        <div class="logo">📚</div><h1>Library Management System</h1><p>Northbridge Public Library</p>
        <div class="field"><label for="username">Username</label><input id="username" name="username" autocomplete="username" required autofocus></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required></div>
        <button class="btn block" type="submit">Sign In</button>
        <p>Access your library workspace securely.</p>
        <div class="demo subtle">Demo accounts<br><code>librarian / Librarian123!</code><br><code>admin / Admin123!</code><br><code>reader / Reader123!</code></div>
      </form></div>
    </section>`;
  document.querySelector("#loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    try {
      state.actor = await api("/api/login", { method: "POST", body: JSON.stringify(Object.fromEntries(form)) });
      state.page = state.actor.role === "READER" ? "Book search" : "Dashboard";
      await renderApp();
    } catch (error) { notify(error.message, true); }
  });
}

function pagesForRole() {
  if (state.actor.role === "READER") return ["Book search", "My account"];
  if (state.actor.role === "GUEST") return ["Book search"];
  const staff = ["Dashboard", "Book search", "Books", "Readers", "Borrow book", "Return book", "Reservations", "Fines", "Reports"];
  return state.actor.role === "ADMIN" ? [...staff, "Staff & settings", "Audit log"] : staff;
}

async function renderApp() {
  const actor = state.actor;
  if (!actor) return renderLogin();
  const pages = pagesForRole();
  if (!pages.includes(state.page)) state.page = actor.role === "READER" ? "Book search" : "Dashboard";
  const initials = actor.full_name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
  root.innerHTML = `
    <header class="topbar"><div class="brand"><span class="logo">📚</span><span>Northbridge Public Library<small>Library Management System</small></span></div>
      <div class="top-actions"><span class="role">${esc(roleName(actor.role))}</span><span class="avatar">${esc(initials)}</span><strong class="name">${esc(actor.full_name)}</strong><button class="link" data-action="logout">Sign Out</button></div>
    </header>
    <div class="layout"><aside class="sidebar"><div class="nav-caption">${actor.role === "READER" ? "READER PORTAL" : "WORKSPACE"}</div>
      <nav class="nav" aria-label="Main menu">${pages.map((page) => `<button data-page="${esc(page)}" class="${state.page === page ? "active" : ""}"><span class="ni">${NAV.find(([name]) => name === page)?.[1] || "•"}</span>${esc(pageLabel(page))}</button>`).join("")}</nav>
    </aside><main class="main" id="main"></main></div>`;
  root.querySelectorAll("[data-page]").forEach((button) => button.addEventListener("click", () => { state.page = button.dataset.page; renderApp(); }));
  root.querySelector("[data-action=logout]").addEventListener("click", () => run(async () => { await api("/api/logout", { method: "POST", body: "{}" }); renderLogin(); }));
  await renderPage();
}

function pageLabel(page) {
  return ({ Books: "Book management", Readers: "Reader management", "Staff & settings": "Accounts & settings", "Audit log": "Activity log" })[page] || page;
}

function heading(page, action = "") {
  const [title, description] = TITLES[page] || [page, "Library management"];
  return `<div class="crumb">Workspace › ${esc(title)}</div><div class="heading"><div><h1>${esc(title)}</h1><p>${esc(description)}</p></div>${action}</div>`;
}

function card(title, body, extra = "") {
  return `<section class="card ${extra}">${title ? `<h2>${esc(title)}</h2>` : ""}${body}</section>`;
}

function badge(status) {
  const text = String(status || "Unknown");
  const color = /overdue|lost|damaged|suspended|expired|locked/i.test(text) ? "red" : /ready|reserved|unpaid|queue|waiting/i.test(text) ? "yellow" : /returned|paid|active|available|fulfilled/i.test(text) ? "green" : "blue";
  return `<span class="badge ${color}">${esc(text)}</span>`;
}

function table(columns, rows, empty = "No records to display.") {
  if (!rows.length) return `<div class="empty">${esc(empty)}</div>`;
  return `<div class="table-wrap"><table><thead><tr>${columns.map((col) => `<th>${esc(col.label)}</th>`).join("")}</tr></thead><tbody>${rows.map((row, index) => `<tr data-row="${index}">${columns.map((col) => `<td>${col.render ? col.render(row[col.key], row) : esc(row[col.key])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

function metric(label, value, note, icon) {
  return `<section class="card stat-card"><span class="stat-icon">${icon}</span><div class="stat-label">${esc(label)}</div><div class="stat-value">${esc(value)}</div><div class="stat-note">${esc(note)}</div></section>`;
}

function inputField(name, label, value = "", type = "text", required = false, options = null) {
  const req = required ? "required" : "";
  const control = options
    ? `<select name="${esc(name)}" ${req}>${options.map((option) => `<option value="${esc(option.value ?? option)}" ${(option.value ?? option) === value ? "selected" : ""}>${esc(option.label ?? option)}</option>`).join("")}</select>`
    : `<input name="${esc(name)}" type="${esc(type)}" value="${esc(value)}" ${req} ${type === "password" ? "autocomplete=\"new-password\"" : ""}>`;
  return `<div class="field"><label>${esc(label)}${required ? " *" : ""}</label>${control}</div>`;
}

function openForm(title, fields, onSubmit, submitText = "Save") {
  modal.innerHTML = `<form class="modal-inner" id="modalForm"><h2>${esc(title)}</h2>${fields.map((field) => inputField(...field)).join("")}<div class="modal-actions"><button type="button" class="btn secondary" data-cancel>Cancel</button><button type="submit" class="btn">${esc(submitText)}</button></div></form>`;
  modal.querySelector("[data-cancel]").addEventListener("click", () => modal.close());
  modal.querySelector("form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(event.currentTarget));
    try { await onSubmit(values); modal.close(); await renderApp(); } catch (error) { notify(error.message, true); }
  });
  modal.showModal();
}

async function renderPage() {
  const main = document.querySelector("#main");
  const renderers = {
    Dashboard: renderDashboard, "Book search": renderSearch, Books: renderBooks, Readers: renderReaders,
    "Borrow book": renderBorrow, "Return book": renderReturn, Reservations: renderReservations,
    Fines: renderFines, Reports: renderReports, "Staff & settings": renderSettings,
    "Audit log": renderAudit, "My account": renderMyAccount
  };
  try { main.innerHTML = await renderers[state.page](); }
  catch (error) { main.innerHTML = heading(state.page) + `<div class="notice">${esc(error.message)}</div>`; }
  bindPageActions();
}

async function renderDashboard() {
  const data = await api("/api/dashboard");
  const recent = table([
    { key: "loan_date", label: "Loan date" }, { key: "full_name", label: "Reader" }, { key: "title", label: "Book" },
    { key: "barcode", label: "Barcode" }, { key: "due_date", label: "Due date" }, { key: "status", label: "Status", render: badge }
  ], data.recent_loans);
  return heading("Dashboard", `<button class="btn" data-action="goto" data-page="Borrow book">Borrow Book</button>`) +
    `<div class="grid4 mb">${metric("Books Borrowed Today", data.borrowed_today, "Today's checkouts", "📤")}${metric("Active Readers", data.active_readers, "Valid membership cards", "👥")}${metric("Overdue Loans", data.overdue, "Need attention", "⏰")}${metric("Unpaid Fines", money(data.unpaid_fines), "Outstanding balance", "💰")}</div>` +
    `<div class="grid2">${card("Recent Loans", recent)}${card("Library at a glance", `<p>Inventory copies <b class="figure">${esc(data.inventory)}</b></p><p>New readers today <b class="figure">${esc(data.new_readers)}</b></p><p>Overdue books <b class="figure">${esc(data.overdue)}</b></p><div class="actions mt"><button class="btn" data-action="goto" data-page="Borrow book">Borrow</button><button class="btn secondary" data-action="goto" data-page="Return book">Return</button></div>`)}</div>` +
    (data.overdue ? `<div class="notice">There are ${esc(data.overdue)} overdue loans that need follow-up.</div>` : "");
}

async function renderSearch() {
  const params = new URLSearchParams({ q: document.querySelector("#searchQuery")?.value || "" });
  const rows = await api(`/api/books?${params}`);
  state.books = rows;
  const content = table([
    { key: "isbn", label: "ISBN" }, { key: "title", label: "Book title" }, { key: "authors", label: "Author(s)" },
    { key: "category", label: "Category" }, { key: "publication_year", label: "Year" },
    { key: "available_copies", label: "Available" }, { key: "shelf_location", label: "Shelf" },
    { key: "book_id", label: "Action", render: (_value, row) => row.available_copies > 0 ? badge("Available") : state.actor.role === "READER" ? `<button class="btn small" data-action="reserve" data-id="${row.book_id}">Reserve</button>` : badge("On loan") }
  ], rows, "No books found. Try a different title, author, or ISBN.");
  return heading("Book search") + card("Catalogue", `<div class="toolbar"><input id="searchQuery" placeholder="Title, author, ISBN, publisher, or category" value="${esc(params.get("q"))}"><button class="btn" data-action="search">Search</button></div>${content}`);
}

async function renderBooks() {
  const [rows, query] = [await api("/api/books"), document.querySelector("#bookManageQuery")?.value || ""];
  const filtered = query ? rows.filter((row) => [row.title, row.authors, row.isbn].some((value) => String(value || "").toLowerCase().includes(query.toLowerCase()))) : rows;
  state.books = rows;
  const listing = table([
    { key: "title", label: "Book title" }, { key: "authors", label: "Author(s)" }, { key: "isbn", label: "ISBN" },
    { key: "category", label: "Category" }, { key: "total_copies", label: "Copies" }, { key: "available_copies", label: "Available" },
    { key: "shelf_location", label: "Shelf" }, { key: "book_id", label: "Actions", render: (_v, row) => `<button class="link" data-action="edit-book" data-id="${row.book_id}">Edit</button> · <button class="link" data-action="add-copy" data-id="${row.book_id}">Add copy</button> · <button class="link" data-action="delete-book" data-id="${row.book_id}">Delete</button>` }
  ], filtered);
  return heading("Books", `<button class="btn" data-action="add-book">+ Add Book</button>`) + card("Book catalogue", `<div class="toolbar"><input id="bookManageQuery" placeholder="Search books" value="${esc(query)}"><button class="btn secondary" data-action="filter-books">Search</button></div>${listing}`);
}

async function renderReaders() {
  const rows = await api("/api/readers");
  state.readers = rows;
  return heading("Readers", `<button class="btn" data-action="add-reader">+ Add Reader</button>`) + card("Membership cards", table([
    { key: "card_number", label: "Card ID" }, { key: "full_name", label: "Reader" }, { key: "reader_type", label: "Type" },
    { key: "email", label: "Email" }, { key: "current_loans", label: "Loans" },
    { key: "status", label: "Status", render: badge }, { key: "expiry_date", label: "Expires" },
    { key: "reader_id", label: "Actions", render: (_v, row) => `<button class="link" data-action="reader-status" data-id="${row.reader_id}" data-status="${row.status === "ACTIVE" ? "SUSPENDED" : "ACTIVE"}">${row.status === "ACTIVE" ? "Suspend" : "Renew / Activate"}</button>` }
  ], rows));
}

async function renderBorrow() {
  const loans = await api("/api/loans");
  const active = loans.filter((loan) => ["BORROWED", "OVERDUE"].includes(loan.status));
  return heading("Borrow book") + `<div class="grid2"><section class="card"><h2>01 · Validate reader card</h2><form data-form="checkout">${inputField("card_number", "Reader card ID", "", "text", true)}${inputField("barcode", "Copy barcode (scanner input)", "", "text", true)}<div class="actions"><button class="btn">Confirm Loan</button><button type="reset" class="btn secondary">Clear</button></div></form></section>${card("Loan rules", `<p>Loan period <b class="figure">14 days</b></p><p>Maximum books <b class="figure">5</b></p><p>Renewals allowed <b class="figure">2</b></p><div class="notice">The reader's account and copy availability are checked before checkout.</div>`)}</div><div class="mt">${card("Current loans", table([{ key: "card_number", label: "Card" }, { key: "full_name", label: "Reader" }, { key: "title", label: "Book" }, { key: "barcode", label: "Barcode" }, { key: "due_date", label: "Due date" }, { key: "status", label: "Status", render: badge }], active))}</div>`;
}

async function renderReturn() {
  const loans = await api("/api/loans");
  const active = loans.filter((loan) => ["BORROWED", "OVERDUE"].includes(loan.status));
  return heading("Return book") + `<div class="grid2"><section class="card"><h2>02 · Locate active loan</h2><form data-form="return">${inputField("barcode", "Copy barcode", "", "text", true)}${inputField("condition", "Book condition", "Good", "text", true, ["Good", "Damaged", "Lost"])}${inputField("compensation", "Compensation (VND, for damaged/lost)", "0", "number")}<button class="btn">Confirm Return</button></form></section>${card("Return guidance", "<p>Late fees are calculated using the configured daily rate.</p><p>Returning a title with a waiting hold notifies the next reader.</p>")}</div><div class="mt">${card("Active loans", table([{ key: "barcode", label: "Barcode" }, { key: "title", label: "Book" }, { key: "full_name", label: "Reader" }, { key: "loan_date", label: "Borrowed" }, { key: "due_date", label: "Due date" }, { key: "status", label: "Status", render: badge }], active))}</div>`;
}

async function renderReservations() {
  const rows = await api("/api/reservations");
  state.reservations = rows;
  return heading("Reservations") + card("Reservation queue", table([
    { key: "reservation_id", label: "ID" }, { key: "title", label: "Book" }, { key: "card_number", label: "Reader card" },
    { key: "full_name", label: "Reader" }, { key: "reservation_date", label: "Requested" },
    { key: "expiry_date", label: "Pickup until" }, { key: "status", label: "Status", render: badge },
    { key: "reservation_id", label: "Action", render: (id, row) => ["WAITING", "READY"].includes(row.status) ? `<button class="link" data-action="cancel-hold" data-id="${id}">Cancel</button>` : "—" }
  ], rows));
}

async function renderFines() {
  const rows = await api(`/api/fines${canStaff() ? "?unpaid=1" : ""}`);
  state.fines = rows;
  return heading("Fines") + card(canStaff() ? "Unpaid balances" : "Your fines", table([
    { key: "fine_id", label: "Fine ID" }, { key: "card_number", label: "Reader card" }, { key: "full_name", label: "Reader" },
    { key: "title", label: "Book" }, { key: "reason", label: "Reason" }, { key: "amount", label: "Amount", render: (amount) => money(amount) },
    { key: "status", label: "Status", render: badge },
    ...(canStaff() ? [{ key: "fine_id", label: "Action", render: (id) => `<button class="btn small" data-action="pay-fine" data-id="${id}">Record payment</button>` }] : [])
  ], rows, "No outstanding fines."));
}

async function renderReports() {
  const rows = await api("/api/reports?type=Current%20inventory");
  state.reportRows = rows;
  return heading("Reports") + `<section class="card"><div class="toolbar"><select id="reportType"><option>Books borrowed per period</option><option>Most borrowed titles</option><option>Overdue loans</option><option>Active readers</option><option>Fine revenue</option><option selected>Current inventory</option></select><input id="reportStart" type="date" aria-label="From date"><input id="reportEnd" type="date" aria-label="To date"><button class="btn" data-action="generate-report">Generate report</button><button class="btn secondary" data-action="export-report">Export CSV</button></div><div id="reportTable">${table(Object.keys(rows[0] || {}).map((key) => ({ key, label: key.replaceAll("_", " ") })), rows)}</div></section>`;
}

async function renderSettings() {
  if (!isAdmin()) throw new Error("Administrator access is required.");
  const [settings, accounts] = await Promise.all([api("/api/settings"), api("/api/accounts")]);
  return heading("Staff & settings", `<button class="btn" data-action="add-staff">+ Add Staff</button>`) +
    `<div class="grid2"><section class="card"><h2>Lending parameters</h2><form data-form="settings" class="grid-half">${inputField("LOAN_DAYS", "Loan period (days)", settings.LOAN_DAYS, "number", true)}${inputField("MAX_BOOKS", "Maximum books", settings.MAX_BOOKS, "number", true)}${inputField("MAX_RENEWALS", "Maximum renewals", settings.MAX_RENEWALS, "number", true)}${inputField("FINE_PER_DAY", "Fine per day (VND)", settings.FINE_PER_DAY, "number", true)}${inputField("HOLD_DAYS", "Reservation pickup days", settings.HOLD_DAYS, "number", true)}<button class="btn">Save settings</button></form></section>${card("Staff accounts", table([{ key: "username", label: "Username" }, { key: "full_name", label: "Name" }, { key: "role", label: "Role", render: roleName }, { key: "status", label: "Status", render: badge }, { key: "account_id", label: "Action", render: (id, row) => `<button class="link" data-action="account-status" data-id="${id}" data-status="${row.status === "ACTIVE" ? "LOCKED" : "ACTIVE"}">${row.status === "ACTIVE" ? "Lock" : "Unlock"}</button>` }], accounts))}</div>`;
}

async function renderAudit() {
  const rows = await api("/api/audit");
  return heading("Audit log") + card("Recent activity", table([{ key: "created_at", label: "Time" }, { key: "username", label: "User" }, { key: "action", label: "Action" }, { key: "entity", label: "Record type" }, { key: "entity_id", label: "Record ID" }], rows));
}

async function renderMyAccount() {
  const result = await api("/api/me");
  const account = result.account;
  const profile = account.profile;
  state.myLoans = account.loans;
  return heading("My account") + `<section class="card mb"><h2>${esc(profile.full_name)} · Card ${esc(profile.card_number)}</h2><p>Membership ${badge(profile.status)} &nbsp; Expires ${esc(profile.expiry_date)}</p><p>Current borrowing: <b>${esc(profile.current_loans)}</b> book(s)</p></section><div class="stack">${card("Current and previous loans", table([{ key: "title", label: "Book" }, { key: "barcode", label: "Copy" }, { key: "loan_date", label: "Borrowed" }, { key: "due_date", label: "Due date" }, { key: "status", label: "Status", render: badge }, { key: "loan_id", label: "Action", render: (id, row) => row.status === "BORROWED" ? `<button class="link" data-action="renew-loan" data-id="${id}">Renew</button>` : "—" }], account.loans))}${card("Reservations", table([{ key: "title", label: "Book" }, { key: "reservation_date", label: "Requested" }, { key: "expiry_date", label: "Pickup until" }, { key: "status", label: "Status", render: badge }, { key: "reservation_id", label: "Action", render: (id, row) => ["WAITING", "READY"].includes(row.status) ? `<button class="link" data-action="cancel-hold" data-id="${id}">Cancel</button>` : "—" }], account.reservations))}${card("Fines", table([{ key: "title", label: "Book" }, { key: "reason", label: "Reason" }, { key: "amount", label: "Amount", render: money }, { key: "status", label: "Status", render: badge }], account.fines, "No fines on your account."))}</div>`;
}

function bindPageActions() {
  const main = document.querySelector("#main");
  main.querySelectorAll("[data-action]").forEach((button) => button.addEventListener("click", () => run(() => handleAction(button))));
  main.querySelectorAll("form[data-form]").forEach((form) => form.addEventListener("submit", (event) => {
    event.preventDefault();
    run(async () => {
      const values = Object.fromEntries(new FormData(form));
      if (form.dataset.form === "checkout") {
        const result = await api("/api/checkout", { method: "POST", body: JSON.stringify(values) });
        notify(`Loan created for ${result.reader}; due ${result.due_date}.`);
      } else if (form.dataset.form === "return") {
        const result = await api("/api/return", { method: "POST", body: JSON.stringify(values) });
        notify(`Returned ${result.title}. Late fine: ${money(result.late_fine)}.`);
      } else if (form.dataset.form === "settings") {
        await api("/api/settings", { method: "POST", body: JSON.stringify(values) });
        notify("Library settings saved.");
      }
      await renderApp();
    });
  }));
}

async function handleAction(button) {
  const { action, id, page } = button.dataset;
  if (action === "goto") { state.page = page; return renderApp(); }
  if (action === "search") return renderPage();
  if (action === "filter-books") return renderPage();
  if (action === "reserve") {
    await api("/api/reservations", { method: "POST", body: JSON.stringify({ book_id: Number(id) }) });
    notify("Reservation added to the queue.");
    return renderApp();
  }
  if (action === "add-book" || action === "edit-book") {
    const book = action === "edit-book" ? state.books.find((item) => item.book_id === Number(id)) : null;
    openForm(book ? "Edit book" : "Add book", [
      ["isbn", "ISBN", book?.isbn || "", "text", true], ["title", "Title", book?.title || "", "text", true],
      ["authors", "Author(s)", book?.authors || ""], ["publisher", "Publisher", book?.publisher || ""],
      ["publication_year", "Publication year", book?.publication_year || "", "number"], ["category", "Category", book?.category || ""],
      ["language", "Language", book?.language || ""], ["pages", "Pages", book?.pages || "", "number"], ["description", "Description", book?.description || ""]
    ], async (values) => { if (book) values.book_id = book.book_id; await api("/api/books", { method: "POST", body: JSON.stringify(values) }); notify("Book saved."); });
    return;
  }
  if (action === "add-copy") {
    const book = state.books.find((item) => item.book_id === Number(id));
    openForm(`Add copy · ${book?.title || "Book"}`, [["barcode", "Barcode", "", "text", true], ["shelf", "Shelf location", ""], ["price", "Price", "0", "number"]], async (values) => { await api(`/api/books/${id}/copies`, { method: "POST", body: JSON.stringify(values) }); notify("Copy added."); });
    return;
  }
  if (action === "delete-book") {
    if (!confirm("Delete this title and its copies?")) return;
    await api(`/api/books/${id}`, { method: "DELETE" });
    notify("Book deleted.");
    return renderApp();
  }
  if (action === "add-reader") {
    openForm("Register reader", [
      ["full_name", "Full name", "", "text", true], ["username", "Login username", "", "text", true],
      ["password", "Initial password (8+ characters)", "", "password", true], ["email", "Email", ""],
      ["phone", "Phone", ""], ["date_of_birth", "Date of birth", "", "date"], ["address", "Address", ""],
      ["reader_type", "Reader type", "Student", "text", true, ["Student", "Teacher", "Other"]], ["expiry_date", "Membership expiry", "", "date"]
    ], async (values) => { const result = await api("/api/readers", { method: "POST", body: JSON.stringify(values) }); notify(`Reader added. Card number: ${result.card_number}`); });
    return;
  }
  if (action === "reader-status") {
    const row = state.readers.find((item) => item.reader_id === Number(id));
    const status = button.dataset.status;
    let body = { status };
    if (status === "ACTIVE") {
      const expiry = prompt("New membership expiry (YYYY-MM-DD):", row?.expiry_date || "");
      if (!expiry) return;
      body.expiry_date = expiry;
    }
    await api(`/api/readers/${id}/status`, { method: "POST", body: JSON.stringify(body) });
    notify("Reader membership updated.");
    return renderApp();
  }
  if (action === "cancel-hold") {
    await api(`/api/reservations/${id}/cancel`, { method: "POST", body: "{}" });
    notify("Reservation cancelled.");
    return renderApp();
  }
  if (action === "renew-loan") {
    const result = await api(`/api/loans/${id}/renew`, { method: "POST", body: "{}" });
    notify(`Loan renewed until ${result.due_date}.`);
    return renderApp();
  }
  if (action === "pay-fine") {
    if (!confirm("Record full payment and issue a receipt?")) return;
    const result = await api(`/api/fines/${id}/pay`, { method: "POST", body: "{}" });
    notify(`Payment recorded. Receipt ${result.receipt_no}.`);
    return renderApp();
  }
  if (action === "generate-report") {
    const params = new URLSearchParams({ type: document.querySelector("#reportType").value, start: document.querySelector("#reportStart").value, end: document.querySelector("#reportEnd").value });
    state.reportRows = await api(`/api/reports?${params}`);
    document.querySelector("#reportTable").innerHTML = table(Object.keys(state.reportRows[0] || {}).map((key) => ({ key, label: key.replaceAll("_", " ") })), state.reportRows);
    notify("Report generated.");
    return;
  }
  if (action === "export-report") {
    if (!state.reportRows.length) return notify("Generate a report with data before exporting.", true);
    const keys = Object.keys(state.reportRows[0]);
    const csv = [keys.join(","), ...state.reportRows.map((row) => keys.map((key) => `"${String(row[key] ?? "").replaceAll('"', '""')}"`).join(","))].join("\r\n");
    const link = document.createElement("a");
    link.href = URL.createObjectURL(new Blob(["\ufeff", csv], { type: "text/csv;charset=utf-8" }));
    link.download = "northbridge-report.csv";
    link.click();
    URL.revokeObjectURL(link.href);
    return;
  }
  if (action === "add-staff") {
    openForm("Add staff account", [["username", "Username", "", "text", true], ["password", "Password (8+ characters)", "", "password", true], ["full_name", "Full name", "", "text", true], ["email", "Email", "", "email"], ["role", "Role", "LIBRARIAN", "text", true, ["LIBRARIAN", "ADMIN"]]], async (values) => { await api("/api/accounts", { method: "POST", body: JSON.stringify(values) }); notify("Staff account created."); });
    return;
  }
  if (action === "account-status") {
    await api(`/api/accounts/${id}/status`, { method: "POST", body: JSON.stringify({ status: button.dataset.status }) });
    notify("Staff account updated.");
    return renderApp();
  }
}

(async function start() {
  try {
    state.actor = await api("/api/me");
    state.page = state.actor.role === "READER" ? "Book search" : "Dashboard";
    await renderApp();
  } catch { renderLogin(); }
})();
