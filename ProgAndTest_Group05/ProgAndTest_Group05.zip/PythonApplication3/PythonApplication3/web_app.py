"""Local browser entry point backed by the existing SQLite business services."""

from __future__ import annotations

import json
import mimetypes
import secrets
import sqlite3
import sys
import threading
import time
import webbrowser
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from lms.database import Database
from lms.services import LibraryError, LibraryService

ROOT = Path(__file__).resolve().parent
WEB_ROOT = ROOT / "web"
SESSION_COOKIE = "northbridge_session"
SESSION_TTL_SECONDS = 30 * 60
MAX_REQUEST_BYTES = 64 * 1024


class LibraryHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], service: LibraryService):
        super().__init__(address, LibraryRequestHandler)
        self.service = service
        self.sessions: dict[str, dict] = {}
        self.sessions_lock = threading.Lock()

    def handle_error(self, request: object, client_address: tuple[str, int]) -> None:
        error_type = sys.exc_info()[0]
        if error_type in {ConnectionResetError, BrokenPipeError}:
            return
        super().handle_error(request, client_address)


class LibraryRequestHandler(BaseHTTPRequestHandler):
    server: LibraryHTTPServer
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: object) -> None:
        print(f"[{self.log_date_time_string()}] {self.address_string()} {format % args}")

    def _send(self, status: int, body: bytes, content_type: str, extra_headers: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            for name, value in extra_headers.items():
                self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, value: object, extra_headers: dict[str, str] | None = None) -> None:
        data = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self._send(status, data, "application/json; charset=utf-8", extra_headers)

    def _body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid Content-Length header.") from exc
        if length < 0 or length > MAX_REQUEST_BYTES:
            raise ValueError("Request body is too large.")
        raw = self.rfile.read(length) if length else b"{}"
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise ValueError("JSON request body must be an object.")
        return value

    def _query(self) -> dict[str, str]:
        parsed = parse_qs(urlparse(self.path).query, keep_blank_values=True)
        return {key: values[-1] for key, values in parsed.items()}

    def _session_id(self) -> str | None:
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
        except CookieError:
            return None
        item = cookie.get(SESSION_COOKIE)
        return item.value if item else None

    def _actor(self) -> dict | None:
        session_id = self._session_id()
        if not session_id:
            return None
        now = time.monotonic()
        with self.server.sessions_lock:
            for key, session in list(self.server.sessions.items()):
                if now - session["last_seen"] > SESSION_TTL_SECONDS:
                    del self.server.sessions[key]
            session = self.server.sessions.get(session_id)
            if session:
                session["last_seen"] = now
                return session["actor"]
        return None

    def _staff(self, actor: dict) -> None:
        if actor.get("role") not in {"LIBRARIAN", "ADMIN"}:
            raise PermissionError("Librarian access is required.")

    def _admin(self, actor: dict) -> None:
        if actor.get("role") != "ADMIN":
            raise PermissionError("Administrator access is required.")

    def _origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        if not origin:
            return self.headers.get("X-Requested-With") == "NorthbridgeLibrary"
        expected = f"http://{self.headers.get('Host', '')}"
        return origin == expected and self.headers.get("X-Requested-With") == "NorthbridgeLibrary"

    def _static(self, path: str) -> None:
        relative = "index.html" if path in {"/", "/index.html"} else path.removeprefix("/")
        target = (WEB_ROOT / relative).resolve()
        if WEB_ROOT.resolve() not in target.parents or not target.is_file():
            self._send(HTTPStatus.NOT_FOUND, b"Not found", "text/plain; charset=utf-8")
            return
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        charset = "; charset=utf-8" if content_type.startswith(("text/", "application/javascript")) else ""
        self._send(HTTPStatus.OK, target.read_bytes(), content_type + charset)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if not parsed.path.startswith("/api/"):
            self._static(parsed.path)
            return
        actor = self._actor()
        if actor is None:
            self._json(HTTPStatus.UNAUTHORIZED, {"error": "Sign in to continue."})
            return
        query = self._query()
        service = self.server.service
        try:
            path = parsed.path
            if path == "/api/me":
                result = {key: actor.get(key) for key in ("account_id", "username", "full_name", "email", "role", "reader_id", "card_number")}
                if actor["role"] == "READER":
                    result["account"] = service.reader_account(actor)
            elif path == "/api/dashboard":
                self._staff(actor)
                result = service.dashboard()
            elif path == "/api/books":
                result = service.list_books(query.get("q", ""), query.get("category", ""), query.get("author", ""), query.get("year", ""))
            elif path == "/api/readers":
                self._staff(actor)
                result = service.list_readers(query.get("q", ""))
            elif path == "/api/loans":
                reader_id = actor.get("reader_id") if actor["role"] == "READER" else None
                result = service.list_loans(reader_id, query.get("status") or None)
            elif path == "/api/reservations":
                reader_id = actor.get("reader_id") if actor["role"] == "READER" else None
                if actor["role"] not in {"READER", "LIBRARIAN", "ADMIN"}:
                    raise PermissionError("Reader or staff access is required.")
                result = service.list_reservations(reader_id)
            elif path == "/api/fines":
                if actor["role"] not in {"READER", "LIBRARIAN", "ADMIN"}:
                    raise PermissionError("Reader or staff access is required.")
                result = service.list_fines(unpaid_only=query.get("unpaid") == "1", reader_id=actor.get("reader_id") if actor["role"] == "READER" else None)
            elif path == "/api/reports":
                self._staff(actor)
                result = service.report(query.get("type", "Books borrowed per period"), query.get("start", ""), query.get("end", ""))
            elif path == "/api/settings":
                self._admin(actor)
                result = service.settings()
            elif path == "/api/accounts":
                self._admin(actor)
                result = service.list_accounts()
            elif path == "/api/audit":
                self._admin(actor)
                result = service.audit_log()
            else:
                self._json(HTTPStatus.NOT_FOUND, {"error": "API route not found."})
                return
            self._json(HTTPStatus.OK, result)
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
        except LibraryError as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})

    def do_POST(self) -> None:
        if not self._origin_ok():
            self._json(HTTPStatus.FORBIDDEN, {"error": "Cross-origin request rejected."})
            return
        try:
            data = self._body()
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/login":
            try:
                actor = self.server.service.login(str(data.get("username", "")), str(data.get("password", "")))
                session_id = secrets.token_urlsafe(32)
                with self.server.sessions_lock:
                    self.server.sessions[session_id] = {"actor": actor, "last_seen": time.monotonic()}
                self._json(HTTPStatus.OK, {key: actor.get(key) for key in ("username", "full_name", "email", "role", "reader_id", "card_number")}, {
                    "Set-Cookie": f"{SESSION_COOKIE}={session_id}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_TTL_SECONDS}"
                })
            except LibraryError as exc:
                self._json(HTTPStatus.UNAUTHORIZED, {"error": str(exc)})
            return
        actor = self._actor()
        if actor is None:
            self._json(HTTPStatus.UNAUTHORIZED, {"error": "Sign in to continue."})
            return
        service = self.server.service
        try:
            if path == "/api/logout":
                service.logout(actor)
                session_id = self._session_id()
                if session_id:
                    with self.server.sessions_lock:
                        self.server.sessions.pop(session_id, None)
                self._json(HTTPStatus.OK, {"ok": True}, {"Set-Cookie": f"{SESSION_COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"})
            elif path == "/api/password":
                service.change_password(actor, str(data.get("current", "")), str(data.get("next", "")))
                self._json(HTTPStatus.OK, {"ok": True})
            elif path == "/api/books":
                self._staff(actor)
                book_id = service.save_book(actor, data, int(data["book_id"]) if data.get("book_id") else None)
                self._json(HTTPStatus.OK, {"book_id": book_id})
            elif path.startswith("/api/books/") and path.endswith("/copies"):
                self._staff(actor)
                book_id = int(path.split("/")[3])
                copy_id = service.add_copy(actor, book_id, str(data.get("barcode", "")), str(data.get("shelf", "")), data.get("price", 0))
                self._json(HTTPStatus.CREATED, {"copy_id": copy_id})
            elif path == "/api/readers":
                self._staff(actor)
                card = service.create_reader(actor, data)
                self._json(HTTPStatus.CREATED, {"card_number": card})
            elif path.startswith("/api/readers/") and path.endswith("/status"):
                self._staff(actor)
                reader_id = int(path.split("/")[3])
                service.update_reader_status(actor, reader_id, str(data.get("status", "")), data.get("expiry_date") or None)
                self._json(HTTPStatus.OK, {"ok": True})
            elif path == "/api/checkout":
                self._staff(actor)
                result = service.checkout(actor, str(data.get("card_number", "")), str(data.get("barcode", "")))
                self._json(HTTPStatus.CREATED, result)
            elif path == "/api/return":
                self._staff(actor)
                result = service.return_copy(actor, str(data.get("barcode", "")), str(data.get("condition", "Good")), data.get("compensation", 0))
                self._json(HTTPStatus.OK, result)
            elif path == "/api/reservations":
                if actor["role"] not in {"READER", "LIBRARIAN", "ADMIN"}:
                    raise PermissionError("Reader or staff access is required.")
                result = service.reserve_book(actor, int(data.get("book_id", 0)), int(data["reader_id"]) if data.get("reader_id") else None)
                self._json(HTTPStatus.CREATED, {"reservation_id": result})
            elif path.startswith("/api/loans/") and path.endswith("/renew"):
                if actor["role"] not in {"READER", "LIBRARIAN", "ADMIN"}:
                    raise PermissionError("Reader or staff access is required.")
                loan_id = int(path.split("/")[3])
                due_date = service.renew_loan(actor, loan_id)
                self._json(HTTPStatus.OK, {"due_date": due_date})
            elif path.startswith("/api/reservations/") and path.endswith("/cancel"):
                if actor["role"] not in {"READER", "LIBRARIAN", "ADMIN"}:
                    raise PermissionError("Reader or staff access is required.")
                reservation_id = int(path.split("/")[3])
                service.cancel_reservation(actor, reservation_id)
                self._json(HTTPStatus.OK, {"ok": True})
            elif path.startswith("/api/fines/") and path.endswith("/pay"):
                self._staff(actor)
                fine_id = int(path.split("/")[3])
                receipt = service.pay_fine(actor, fine_id)
                self._json(HTTPStatus.OK, {"receipt_no": receipt})
            elif path == "/api/settings":
                self._admin(actor)
                service.update_settings(actor, {key: str(data[key]) for key in data})
                self._json(HTTPStatus.OK, {"ok": True})
            elif path == "/api/accounts":
                self._admin(actor)
                account_id = service.create_staff_account(actor, str(data.get("username", "")), str(data.get("password", "")),
                                                         str(data.get("full_name", "")), str(data.get("email", "")), str(data.get("role", "")))
                self._json(HTTPStatus.CREATED, {"account_id": account_id})
            elif path.startswith("/api/accounts/") and path.endswith("/status"):
                self._admin(actor)
                account_id = int(path.split("/")[3])
                service.set_account_status(actor, account_id, str(data.get("status", "")))
                self._json(HTTPStatus.OK, {"ok": True})
            else:
                self._json(HTTPStatus.NOT_FOUND, {"error": "API route not found."})
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
        except (LibraryError, ValueError, TypeError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
        except sqlite3.IntegrityError as exc:
            self._json(HTTPStatus.CONFLICT, {"error": str(exc)})
        except sqlite3.Error:
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "A database error prevented the request."})

    def do_DELETE(self) -> None:
        if not self._origin_ok():
            self._json(HTTPStatus.FORBIDDEN, {"error": "Cross-origin request rejected."})
            return
        actor = self._actor()
        if actor is None:
            self._json(HTTPStatus.UNAUTHORIZED, {"error": "Sign in to continue."})
            return
        try:
            parts = urlparse(self.path).path.strip("/").split("/")
            if len(parts) != 3 or parts[0] != "api" or parts[1] != "books":
                self._json(HTTPStatus.NOT_FOUND, {"error": "API route not found."})
                return
            self._staff(actor)
            self.server.service.delete_book(actor, int(parts[2]))
            self._json(HTTPStatus.OK, {"ok": True})
        except PermissionError as exc:
            self._json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
        except (LibraryError, ValueError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
        except sqlite3.IntegrityError as exc:
            self._json(HTTPStatus.CONFLICT, {"error": str(exc)})
        except sqlite3.Error:
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "A database error prevented the request."})


def main() -> None:
    data_dir = Path.home() / ".northstar_library"
    database = Database(data_dir / "library.db")
    database.initialize()
    service = LibraryService(database)
    service.run_daily_maintenance()
    server = LibraryHTTPServer(("127.0.0.1", 8765), service)
    url = "http://127.0.0.1:8765/"
    print(f"Northbridge Library is running at {url}")
    print("Press Ctrl+C in this window to stop the server.")
    threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Northbridge Library web app.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
