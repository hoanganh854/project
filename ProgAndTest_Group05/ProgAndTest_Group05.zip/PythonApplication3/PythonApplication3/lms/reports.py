"""Dependency-free Excel workbook export for generated reports."""

from __future__ import annotations

import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
ET.register_namespace("", MAIN_NS)
ET.register_namespace("r", REL_NS)


def _column_name(index: int) -> str:
    name = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name


def export_xlsx(path: str | Path, rows: list[dict], columns: list[str] | None = None) -> None:
    """Write rows to a minimal, standards-compliant .xlsx workbook."""
    if columns is None:
        columns = list(rows[0].keys()) if rows else []
    root = ET.Element(f"{{{MAIN_NS}}}worksheet")
    sheet_data = ET.SubElement(root, f"{{{MAIN_NS}}}sheetData")
    all_rows = [columns] + [[row.get(column, "") for column in columns] for row in rows]
    for row_index, values in enumerate(all_rows, 1):
        row_element = ET.SubElement(sheet_data, f"{{{MAIN_NS}}}row", {"r": str(row_index)})
        for column_index, value in enumerate(values, 1):
            cell = ET.SubElement(row_element, f"{{{MAIN_NS}}}c", {"r": f"{_column_name(column_index)}{row_index}"})
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                ET.SubElement(cell, f"{{{MAIN_NS}}}v").text = str(value)
            elif value is not None:
                cell.set("t", "inlineStr")
                inline = ET.SubElement(cell, f"{{{MAIN_NS}}}is")
                ET.SubElement(inline, f"{{{MAIN_NS}}}t").text = str(value)
    workbook = ET.Element(f"{{{MAIN_NS}}}workbook")
    sheets = ET.SubElement(workbook, f"{{{MAIN_NS}}}sheets")
    ET.SubElement(sheets, f"{{{MAIN_NS}}}sheet", {"name": "Report", "sheetId": "1", f"{{{REL_NS}}}id": "rId1"})
    relationships = ET.Element(f"{{{PKG_REL_NS}}}Relationships")
    ET.SubElement(relationships, f"{{{PKG_REL_NS}}}Relationship", {
        "Id": "rId1", "Type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument",
        "Target": "xl/workbook.xml",
    })
    workbook_rels = ET.Element(f"{{{PKG_REL_NS}}}Relationships")
    ET.SubElement(workbook_rels, f"{{{PKG_REL_NS}}}Relationship", {
        "Id": "rId1", "Type": f"{REL_NS}/worksheet", "Target": "worksheets/sheet1.xml",
    })
    content_types = ET.Element(f"{{{CONTENT_NS}}}Types")
    ET.SubElement(content_types, f"{{{CONTENT_NS}}}Default", {"Extension": "rels", "ContentType": "application/vnd.openxmlformats-package.relationships+xml"})
    ET.SubElement(content_types, f"{{{CONTENT_NS}}}Default", {"Extension": "xml", "ContentType": "application/xml"})
    ET.SubElement(content_types, f"{{{CONTENT_NS}}}Override", {"PartName": "/xl/workbook.xml", "ContentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"})
    ET.SubElement(content_types, f"{{{CONTENT_NS}}}Override", {"PartName": "/xl/worksheets/sheet1.xml", "ContentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"})
    path = Path(path)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as workbook_zip:
        workbook_zip.writestr("[Content_Types].xml", ET.tostring(content_types, encoding="utf-8", xml_declaration=True))
        workbook_zip.writestr("_rels/.rels", ET.tostring(relationships, encoding="utf-8", xml_declaration=True))
        workbook_zip.writestr("xl/workbook.xml", ET.tostring(workbook, encoding="utf-8", xml_declaration=True))
        workbook_zip.writestr("xl/_rels/workbook.xml.rels", ET.tostring(workbook_rels, encoding="utf-8", xml_declaration=True))
        workbook_zip.writestr("xl/worksheets/sheet1.xml", ET.tostring(root, encoding="utf-8", xml_declaration=True))
