"""Library Management System application package."""
