"""Tkinter presentation layer following the supplied LMS screen descriptions."""

from __future__ import annotations

import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Any

from .reports import export_xlsx
from .services import LibraryError, LibraryService


COLORS = {
    "primary": "#2861AD", "canvas": "#F3F6FB", "white": "#FFFFFF",
    "text": "#26344A", "ink": "#14213D", "navy": "#14213D",
    "navy_light": "#1D3560", "muted": "#7B8798", "line": "#E2E8F0",
    "green": "#198754", "red": "#C94A4A", "accent": "#F2A93B",
    "blue": "#2861AD", "teal": "#14A09B", "teal_light": "#DFF5F3",
    "amber": "#B9770E",
}

TEXT = {
    "en": {
        "Library Workspace": "Library Workspace", "Dashboard": "Dashboard", "Book search": "Book search",
        "Books": "Books", "Readers": "Readers", "Borrow book": "Borrow book", "Return book": "Return book",
        "Reservations": "Reservations", "Fines": "Fines", "Reports": "Reports", "Staff & settings": "Staff & settings",
        "Audit log": "Audit log", "My account": "My account", "Sign in": "Sign in", "Username": "Username",
        "Password": "Password", "Logout": "Logout", "Search": "Search", "Add book": "Add book",
        "Add reader": "Add reader", "Available": "Available", "Overdue": "Overdue", "Borrowed today": "Borrowed today",
        "New readers": "New readers", "Unpaid fines": "Unpaid fines", "Book catalogue": "Book catalogue",
        "Reader portal": "Reader portal", "English": "English", "Vietnamese": "Vietnamese",
    },
    "vi": {
        "Library Workspace": "Không gian thư viện", "Dashboard": "Tổng quan", "Book search": "Tra cứu sách",
        "Books": "Sách", "Readers": "Bạn đọc", "Borrow book": "Mượn sách", "Return book": "Trả sách",
        "Reservations": "Đặt trước", "Fines": "Tiền phạt", "Reports": "Báo cáo", "Staff & settings": "Nhân viên & cài đặt",
        "Audit log": "Nhật ký hệ thống", "My account": "Tài khoản của tôi", "Sign in": "Đăng nhập",
        "Username": "Tên đăng nhập", "Password": "Mật khẩu", "Logout": "Đăng xuất", "Search": "Tìm kiếm",
        "Add book": "Thêm sách", "Add reader": "Thêm bạn đọc", "Available": "Có sẵn", "Overdue": "Quá hạn",
        "Borrowed today": "Mượn hôm nay", "New readers": "Bạn đọc mới", "Unpaid fines": "Tiền phạt chưa trả",
        "Book catalogue": "Danh mục sách", "Reader portal": "Cổng bạn đọc", "English": "Tiếng Anh", "Vietnamese": "Tiếng Việt",
    },
}


class LibraryApp:
    def __init__(self, root: tk.Tk, service: LibraryService):
        self.root = root
        self.service = service
        self.actor: dict[str, Any] | None = None
        self.language = "en"
        self.page = "Dashboard"
        self._book_rows: dict[str, dict[str, Any]] = {}
        self._reader_rows: dict[str, dict[str, Any]] = {}
        self._reservation_rows: dict[str, dict[str, Any]] = {}
        self.nav_buttons: dict[str, ttk.Button] = {}
        self.root.title("Northbridge Public Library | Library Management System")
        self.root.geometry("1360x860")
        self.root.minsize(1000, 680)
        self.root.configure(bg=COLORS["canvas"])
        self.style = ttk.Style(self.root)
        self.style.theme_use("clam")
        self._configure_styles()
        self.shell = ttk.Frame(root, style="Canvas.TFrame")
        self.shell.pack(fill="both", expand=True)
        self.service.run_daily_maintenance()
        self.show_login()

    def tr(self, text: str) -> str:
        return TEXT[self.language].get(text, text)

    def _configure_styles(self) -> None:
        self.style.configure("Canvas.TFrame", background=COLORS["canvas"])
        self.style.configure("Card.TFrame", background=COLORS["white"], bordercolor=COLORS["line"],
                             lightcolor=COLORS["line"], darkcolor=COLORS["line"], borderwidth=1, relief="solid")
        self.style.configure("Sidebar.TFrame", background=COLORS["navy"])
        self.style.configure("Sidebar.TLabel", background=COLORS["navy"], foreground="#B9C6E0", font=("Arial", 10))
        self.style.configure("Brand.TLabel", background=COLORS["navy"], foreground="white", font=("Arial", 15, "bold"))
        self.style.configure("Header.TLabel", background=COLORS["white"], foreground=COLORS["ink"], font=("Georgia", 11, "bold"))
        self.style.configure("Title.TLabel", background=COLORS["canvas"], foreground=COLORS["ink"], font=("Georgia", 23, "bold"))
        self.style.configure("Sub.TLabel", background=COLORS["canvas"], foreground=COLORS["muted"], font=("Arial", 10))
        self.style.configure("Metric.TLabel", background=COLORS["white"], foreground=COLORS["ink"], font=("Georgia", 23, "bold"))
        self.style.configure("Muted.TLabel", background=COLORS["white"], foreground=COLORS["muted"], font=("Arial", 9))
        self.style.configure("TButton", font=("Arial", 10), padding=(12, 8), background=COLORS["white"], foreground=COLORS["text"])
        self.style.map("TButton", background=[("active", "#F4F8FE")])
        self.style.configure("Accent.TButton", background=COLORS["primary"], foreground="white", font=("Arial", 10, "bold"))
        self.style.map("Accent.TButton", background=[("active", "#3573C4")])
        self.style.configure("Nav.TButton", background=COLORS["navy_light"], foreground="#B9C6E0", anchor="w", padding=(14, 10), font=("Arial", 10), borderwidth=0)
        self.style.map("Nav.TButton", background=[("active", "#354B70")], foreground=[("active", "white")])
        self.style.configure("NavActive.TButton", background="#344B71", foreground="white", anchor="w", padding=(14, 10), font=("Arial", 10, "bold"), borderwidth=0)
        self.style.map("NavActive.TButton", background=[("active", "#405A84")], foreground=[("active", "white")])
        self.style.configure("Treeview", background="white", fieldbackground="white", foreground=COLORS["text"], rowheight=34, font=("Arial", 9), bordercolor=COLORS["line"])
        self.style.configure("Treeview.Heading", background="#F4F7FC", foreground=COLORS["muted"], font=("Arial", 9, "bold"), padding=(8, 8))
        self.style.map("Treeview", background=[("selected", "#E8EFFA")], foreground=[("selected", COLORS["ink"])])
        self.style.configure("TEntry", padding=8, bordercolor="#DBE3EF", lightcolor="#DBE3EF", darkcolor="#DBE3EF")
        self.style.configure("TCombobox", padding=6)

    def _clear(self) -> None:
        for child in self.shell.winfo_children():
            child.destroy()

    def show_login(self) -> None:
        self.actor = None
        self._clear()
        outer = ttk.Frame(self.shell, style="Canvas.TFrame")
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=11)
        outer.columnconfigure(1, weight=10)
        outer.rowconfigure(0, weight=1)
        hero = tk.Canvas(outer, bg=COLORS["ink"], highlightthickness=0)
        hero.grid(row=0, column=0, sticky="nsew")
        hero.bind("<Configure>", lambda event: self._draw_login_hero(hero, event.width, event.height))
        pane = tk.Frame(outer, bg="#EDF2FA")
        pane.grid(row=0, column=1, sticky="nsew")
        card = tk.Frame(pane, bg=COLORS["white"], padx=30, pady=26,
                        highlightbackground=COLORS["line"], highlightthickness=1)
        card.place(relx=0.5, rely=0.5, anchor="center", width=380)
        tk.Label(card, text="📚", bg=COLORS["primary"], fg="white", font=("Arial", 20),
                 width=3, height=1).pack(pady=(0, 12))
        tk.Label(card, text="Library Management System", bg="white", fg=COLORS["ink"],
                 font=("Georgia", 18, "bold")).pack()
        tk.Label(card, text="Northbridge Public Library", bg="white", fg=COLORS["muted"],
                 font=("Arial", 10)).pack(pady=(6, 19))
        tk.Label(card, text=self.tr("Username"), bg="white", fg=COLORS["text"],
                 font=("Arial", 9, "bold")).pack(anchor="w")
        username = ttk.Entry(card)
        username.pack(fill="x", pady=(5, 13), ipady=2)
        tk.Label(card, text=self.tr("Password"), bg="white", fg=COLORS["text"],
                 font=("Arial", 9, "bold")).pack(anchor="w")
        password = ttk.Entry(card, show="•")
        password.pack(fill="x", pady=(5, 13), ipady=2)
        tk.Label(card, text="Language / Ngôn ngữ", bg="white", fg=COLORS["text"],
                 font=("Arial", 9, "bold")).pack(anchor="w")
        language = ttk.Combobox(card, state="readonly", values=["English", "Tiếng Việt"])
        language.set("English" if self.language == "en" else "Tiếng Việt")
        language.pack(fill="x", pady=(5, 16))
        language.bind("<<ComboboxSelected>>", lambda _event: self._set_language(language.get()))

        def login(_event: Any = None) -> None:
            try:
                self.actor = self.service.login(username.get(), password.get())
                self.open_workspace()
            except (LibraryError, sqlite3.IntegrityError) as exc:
                messagebox.showerror("Sign in failed", str(exc), parent=self.root)
                password.delete(0, "end")
                password.focus_set()

        ttk.Button(card, text="Sign In", style="Accent.TButton", command=login).pack(fill="x", ipady=2)
        ttk.Button(card, text="Browse the catalogue", command=self._open_guest_search).pack(fill="x", pady=(9, 0))
        username.bind("<Return>", lambda _event: password.focus_set())
        password.bind("<Return>", login)
        username.focus_set()

    @staticmethod
    def _draw_login_hero(canvas: tk.Canvas, width: int, height: int) -> None:
        canvas.delete("all")
        canvas.create_rectangle(0, 0, width, height, fill=COLORS["ink"], outline="")
        canvas.create_oval(width * .05, height * .02, width * .95, height * .62,
                           fill=COLORS["navy_light"], outline="")
        canvas.create_text(width / 2, height * .12, text="N O R T H B R I D G E   P U B L I C   L I B R A R Y",
                           fill="#B9C6E0", font=("Arial", 9, "bold"))
        canvas.create_text(width / 2, height * .25, text="📚", fill="white", font=("Arial", 56))
        canvas.create_text(width / 2, height * .39, text="A world of stories,",
                           fill="white", font=("Georgia", 25, "bold"))
        canvas.create_text(width / 2, height * .45, text="waiting to be found.",
                           fill="#D7E2F3", font=("Georgia", 21, "italic"))
        colors = ["#F2A93B", "#E0566E", "#14A09B", "#5D94DC", "#F7D9A0", "#7A5AF8",
                  "#F2A93B", "#3573C4", "#E0566E", "#14A09B", "#5D94DC", "#F7D9A0"]
        shelf_y = height * .94
        gap = max(4, width * .008)
        book_width = min(42, (width * .72 - gap * (len(colors) - 1)) / len(colors))
        total_width = len(colors) * book_width + (len(colors) - 1) * gap
        left = (width - total_width) / 2
        for index, color in enumerate(colors):
            book_height = height * (.20 + ((index * 17) % 25) / 100)
            x1 = left + index * (book_width + gap)
            canvas.create_rectangle(x1, shelf_y - book_height, x1 + book_width,
                                    shelf_y, fill=color, outline="")
            canvas.create_rectangle(x1 + book_width * .76, shelf_y - book_height, x1 + book_width,
                                    shelf_y, fill="#000000", stipple="gray50", outline="")
        canvas.create_rectangle(width * .09, shelf_y, width * .91, shelf_y + 12,
                                fill="#0B1428", outline="")
        canvas.create_text(width / 2, height * .985, text="Discover  ·  Borrow  ·  Return",
                           fill="#B9C6E0", font=("Arial", 10))

    def _set_language(self, value: str) -> None:
        self.language = "vi" if value == "Tiếng Việt" else "en"
        if self.actor:
            self.open_workspace()
        else:
            self.show_login()

    def _open_guest_search(self) -> None:
        self.actor = {"role": "GUEST", "full_name": "Guest", "username": "guest"}
        self.page = "Book search"
        self.open_workspace()

    def open_workspace(self) -> None:
        self._clear()
        actor = self.actor or {"role": "GUEST", "full_name": "Guest", "username": "guest"}
        role = actor["role"]
        frame = ttk.Frame(self.shell, style="Canvas.TFrame")
        frame.pack(fill="both", expand=True)

        topbar = tk.Frame(frame, bg=COLORS["white"], padx=22, pady=10,
                          highlightbackground=COLORS["line"], highlightthickness=1)
        topbar.pack(fill="x", side="top")
        tk.Label(topbar, text="📚", bg=COLORS["primary"], fg="white", font=("Arial", 15),
                 width=2, height=1).pack(side="left", padx=(0, 10))
        brand = tk.Frame(topbar, bg="white")
        brand.pack(side="left")
        tk.Label(brand, text="Northbridge Public Library", bg="white", fg=COLORS["ink"],
                 font=("Arial", 11, "bold")).pack(anchor="w")
        tk.Label(brand, text="Library Management System", bg="white", fg=COLORS["muted"],
                 font=("Arial", 8)).pack(anchor="w")
        actions = tk.Frame(topbar, bg="white")
        actions.pack(side="right")
        role_title = {"ADMIN": "Administrator", "LIBRARIAN": "Librarian", "READER": "Reader", "GUEST": "Guest"}[role]
        tk.Label(actions, text=role_title, bg="#E5F4EC", fg=COLORS["green"],
                 font=("Arial", 9, "bold"), padx=10, pady=5).pack(side="left", padx=(0, 12))
        initials = "".join(part[0] for part in actor.get("full_name", "Guest").split()[:2]).upper()
        tk.Label(actions, text=initials, bg=COLORS["accent"], fg="white",
                 font=("Arial", 9, "bold"), width=3, height=1).pack(side="left", padx=(0, 8))
        tk.Label(actions, text=actor.get("full_name", "Guest"), bg="white", fg=COLORS["text"],
                 font=("Arial", 9, "bold")).pack(side="left", padx=(0, 14))
        if role != "GUEST":
            ttk.Button(actions, text="Sign Out", command=self._logout).pack(side="left")
        else:
            ttk.Button(actions, text="Sign In", command=self.show_login).pack(side="left")

        body = ttk.Frame(frame, style="Canvas.TFrame")
        body.pack(fill="both", expand=True)
        sidebar = ttk.Frame(body, style="Sidebar.TFrame", width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        tk.Label(sidebar, text="READER PORTAL" if role == "READER" else "WORKSPACE",
                 bg=COLORS["navy_light"], fg="#B9C6E0", font=("Arial", 8, "bold"),
                 anchor="w", padx=18, pady=15).pack(fill="x", pady=(7, 5))
        staff_pages = ["Dashboard", "Book search", "Books", "Readers", "Borrow book", "Return book", "Reservations", "Fines", "Reports"]
        if role == "READER":
            pages = ["Book search", "My account"]
        elif role == "GUEST":
            pages = ["Book search"]
        elif role == "ADMIN":
            pages = staff_pages + ["Staff & settings", "Audit log"]
        else:
            pages = staff_pages
        icons = {"Dashboard": "📊", "Book search": "🔍", "Books": "📚", "Readers": "👥",
                 "Borrow book": "📤", "Return book": "📥", "Reservations": "🔖", "Fines": "💳",
                 "Reports": "📈", "Staff & settings": "⚙", "Audit log": "🕒", "My account": "👤"}
        labels = {"Books": "Book management", "Readers": "Reader management",
                  "Staff & settings": "Accounts & settings", "Audit log": "Activity log"}
        self.nav_buttons = {}
        for page in pages:
            button = ttk.Button(sidebar, text=f"{icons.get(page, '')}  {self.tr(labels.get(page, page))}",
                                style="Nav.TButton", command=lambda p=page: self.show_page(p))
            button.pack(fill="x", padx=8, pady=2)
            self.nav_buttons[page] = button
        bottom = ttk.Frame(sidebar, style="Sidebar.TFrame")
        bottom.pack(side="bottom", fill="x", padx=10, pady=14)
        if role != "GUEST":
            ttk.Button(bottom, text="Change password", style="Nav.TButton", command=self._change_password).pack(fill="x")

        self.content = ttk.Frame(body, style="Canvas.TFrame", padding=(24, 20))
        self.content.pack(side="left", fill="both", expand=True)
        self.page_area = ttk.Frame(self.content, style="Canvas.TFrame")
        self.page_area.pack(fill="both", expand=True)
        if self.page not in pages:
            self.page = "Book search" if role in {"GUEST", "READER"} else "Dashboard"
        self.show_page(self.page)

    def _change_password(self) -> None:
        if not self.actor:
            return
        values = self._form("Change password", [("old_password", "Current password *", ""),
                                                ("new_password", "New password (8+ characters) *", "")])
        if values is not None and self._run(
            lambda: self.service.change_password(self.actor, values["old_password"], values["new_password"]),
            "Password updated.",
        ):
            return

    def _logout(self) -> None:
        if self.actor:
            try:
                self.service.logout(self.actor)
            except (LibraryError, sqlite3.Error) as exc:
                messagebox.showerror("Logout failed", str(exc), parent=self.root)
                return
        self.show_login()

    def show_page(self, page: str) -> None:
        role = self.actor["role"] if self.actor else "GUEST"
        if role == "READER" and page not in {"Book search", "My account"}:
            page = "Book search"
        elif role == "GUEST" and page != "Book search":
            page = "Book search"
        self.page = page
        for nav_page, button in self.nav_buttons.items():
            button.configure(style="NavActive.TButton" if nav_page == page else "Nav.TButton")
        for child in self.page_area.winfo_children():
            child.destroy()
        titles = {
            "Dashboard": ("Dashboard", "Service desk overview and today's circulation."),
            "Book search": ("Book catalogue", "Find a title by ISBN, author, publisher, category, or year."),
            "Books": ("Book management", "Manage bibliographic records and physical copies."),
            "Readers": ("Reader management", "Manage membership cards, status, and borrowing."),
            "Borrow book": ("Borrow a book", "Validate a reader card and check out an available copy."),
            "Return book": ("Return a book", "Record the copy condition and any applicable fine."),
            "Reservations": ("Reservations", "Review the waiting queue and pickup holds."),
            "Fines": ("Fines & payments", "Record payments and issue a receipt number."),
            "Reports": ("Reports", "Generate circulation, inventory, reader, and revenue reports."),
            "Staff & settings": ("Accounts & settings", "Manage staff access and library parameters."),
            "Audit log": ("Audit log", "Review recorded actions and timestamps."),
            "My account": ("My account", "Your current loans, reservations, and fines."),
        }
        title, subtitle = titles.get(page, (page, "Library management"))
        tk.Label(self.page_area, text=f"Workspace  ›  {self.tr(title)}", bg=COLORS["canvas"],
                 fg=COLORS["muted"], font=("Arial", 9)).pack(anchor="w")
        ttk.Label(self.page_area, text=self.tr(title), style="Title.TLabel").pack(anchor="w", pady=(5, 0))
        ttk.Label(self.page_area, text=self.tr(subtitle), style="Sub.TLabel").pack(anchor="w", pady=(5, 18))
        handlers = {
            "Dashboard": self._dashboard, "Book search": self._book_search, "Books": self._books,
            "Readers": self._readers, "Borrow book": self._borrow, "Return book": self._return,
            "Reservations": self._reservations, "Fines": self._fines, "Reports": self._reports,
            "Staff & settings": self._settings, "Audit log": self._audit, "My account": self._my_account,
        }
        handlers.get(page, self._dashboard)()

    def _card(self, parent: tk.Widget, padding: int = 17) -> ttk.Frame:
        card = ttk.Frame(parent, style="Card.TFrame", padding=padding)
        card.configure(relief="flat")
        return card

    def _button(self, parent: tk.Widget, text: str, command: Any, primary: bool = False) -> ttk.Button:
        return ttk.Button(parent, text=self.tr(text), command=command, style="Accent.TButton" if primary else "TButton")

    def _table(self, parent: tk.Widget, columns: list[tuple[str, str, int]], rows: list[dict[str, Any]], id_key: str,
               cache: dict[str, dict[str, Any]] | None = None) -> ttk.Treeview:
        names = [name for name, _label, _width in columns]
        table = ttk.Treeview(parent, columns=names, show="headings", selectmode="browse")
        for name, label, width in columns:
            table.heading(name, text=label)
            table.column(name, width=width, minwidth=65, anchor="w")
        for index, row in enumerate(rows):
            iid = str(row.get(id_key, ""))
            if not iid or table.exists(iid):
                iid = f"row-{index}"
            values = [row.get(name, "") if row.get(name) is not None else "" for name in names]
            table.insert("", "end", iid=iid, values=values)
            if cache is not None:
                cache[iid] = row
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=table.yview)
        table.configure(yscrollcommand=scrollbar.set)
        table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        return table

    @staticmethod
    def _selected_id(table: ttk.Treeview | None) -> int | None:
        if table is None or not table.selection():
            return None
        try:
            return int(table.selection()[0])
        except ValueError:
            return None

    def _run(self, action: Any, success: str | None = None) -> Any:
        try:
            result = action()
            if success:
                messagebox.showinfo("Library", success, parent=self.root)
            return True if result is None else result
        except (LibraryError, sqlite3.IntegrityError, sqlite3.OperationalError, ValueError) as exc:
            messagebox.showerror("Unable to complete action", str(exc), parent=self.root)
            return None

    def _dashboard(self) -> None:
        stats = self.service.dashboard()
        metrics = [("Borrowed today", stats["borrowed_today"], COLORS["blue"]), ("Overdue", stats["overdue"], COLORS["red"]),
                   ("New readers", stats["new_readers"], COLORS["teal"]), ("Unpaid fines", f"{stats['unpaid_fines']:,.0f} VND", COLORS["amber"])]
        row = ttk.Frame(self.page_area, style="Canvas.TFrame")
        row.pack(fill="x", pady=(0, 19))
        for label, value, accent in metrics:
            card = self._card(row, 18)
            card.pack(side="left", fill="both", expand=True, padx=(0, 12))
            tk.Label(card, text=self.tr(label), bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).pack(anchor="w")
            tk.Label(card, text=str(value), bg="white", fg=accent, font=("Segoe UI", 21, "bold")).pack(anchor="w", pady=(7, 0))
        recent = self._card(self.page_area, 16)
        recent.pack(fill="both", expand=True)
        ttk.Label(recent, text="Recent loans", style="Header.TLabel").pack(anchor="w", pady=(0, 12))
        self._table(recent, [("loan_date", "Loan date", 110), ("full_name", "Reader", 170), ("title", "Title", 240),
                             ("barcode", "Barcode", 120), ("due_date", "Due date", 110), ("status", "Status", 100)],
                    stats["recent_loans"], "barcode")
        shortcuts = ttk.Frame(self.page_area, style="Canvas.TFrame")
        shortcuts.pack(fill="x", pady=(15, 0))
        if self.actor and self.actor["role"] in {"LIBRARIAN", "ADMIN"}:
            pages = ("Book search", "Books", "Readers", "Borrow book", "Return book", "Reservations", "Fines", "Reports")
            for page in pages:
                self._button(shortcuts, page, lambda p=page: self.show_page(p), page == "Borrow book").pack(side="left", padx=(0, 8))

    def _book_search(self) -> None:
        bar = self._card(self.page_area, 14)
        bar.pack(fill="x", pady=(0, 14))
        query = ttk.Entry(bar)
        query.pack(side="left", fill="x", expand=True, padx=(0, 8))
        query.insert(0, "")
        table_card = self._card(self.page_area, 12)
        table_card.pack(fill="both", expand=True)
        self._book_rows = {}
        table: ttk.Treeview | None = None

        def search(_event: Any = None) -> None:
            nonlocal table
            for child in table_card.winfo_children():
                child.destroy()
            self._book_rows = {}
            rows = self._run(lambda: self.service.list_books(query.get())) or []
            table = self._table(table_card, [("isbn", "ISBN", 130), ("title", "Title", 240), ("authors", "Author(s)", 170),
                                               ("category", "Category", 135), ("available_copies", "Available", 90),
                                               ("shelf_location", "Shelf", 115)], rows, "book_id", self._book_rows)
            if not rows:
                tk.Label(table_card, text="No book found. Try another search.", bg="white", fg=COLORS["muted"], font=("Segoe UI", 10)).place(relx=.5, rely=.5, anchor="center")

        self._button(bar, "Search", search, True).pack(side="left")
        query.bind("<Return>", search)
        actions = ttk.Frame(self.page_area, style="Canvas.TFrame")
        actions.pack(fill="x", pady=(12, 0))
        actor_role = self.actor["role"] if self.actor else "GUEST"
        if actor_role in {"LIBRARIAN", "ADMIN"}:
            self._button(actions, "Manage books", lambda: self.show_page("Books")).pack(side="left")
        elif actor_role == "READER":
            def reserve() -> None:
                book_id = self._selected_id(table)
                if book_id is None:
                    messagebox.showwarning("Select a title", "Select a book first.", parent=self.root)
                    return
                result = self._run(lambda: self.service.reserve_book(self.actor, book_id), "Reservation added to the queue.")
                if result:
                    search()
            self._button(actions, "Reserve selected title", reserve, True).pack(side="left")
            self._button(actions, "My reservations", lambda: self.show_page("My account")).pack(side="left", padx=8)

    def _books(self) -> None:
        card = self._card(self.page_area, 12)
        card.pack(fill="both", expand=True)
        self._book_rows = {}
        table = self._table(card, [("isbn", "ISBN", 120), ("title", "Title", 210), ("authors", "Author(s)", 145),
                                   ("publisher", "Publisher", 130), ("category", "Category", 120),
                                   ("total_copies", "Copies", 70), ("available_copies", "Available", 85),
                                   ("shelf_location", "Shelf", 100)], self.service.list_books(), "book_id", self._book_rows)
        row = ttk.Frame(self.page_area, style="Canvas.TFrame")
        row.pack(fill="x", pady=(12, 0))
        def form(book: dict[str, Any] | None = None) -> dict[str, str] | None:
            fields = [("isbn", "ISBN *", book.get("isbn", "") if book else ""), ("title", "Title *", book.get("title", "") if book else ""),
                      ("authors", "Author(s)", book.get("authors", "") if book else ""), ("publisher", "Publisher", book.get("publisher", "") if book else ""),
                      ("publication_year", "Publication year", book.get("publication_year", "") if book else ""), ("category", "Category", book.get("category", "") if book else ""),
                      ("language", "Language", book.get("language", "") if book else ""), ("pages", "Pages", book.get("pages", "") if book else ""),
                      ("description", "Description", book.get("description", "") if book else "")]
            data = self._form("Edit book" if book else "Add book", fields)
            if data is not None:
                result = self._run(lambda: self.service.save_book(self.actor, data, book["book_id"] if book else None), "Book saved.")
                if result:
                    self.show_page("Books")
        def edit() -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select a book", "Select a book to edit.", parent=self.root)
            else:
                form(self._book_rows[str(selected)])
        def add_copy() -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select a title", "Select a title before adding a copy.", parent=self.root)
                return
            data = self._form("Add physical copy", [("barcode", "Barcode *", ""), ("shelf", "Shelf location", ""), ("price", "Price", "0")])
            if data is not None and self._run(lambda: self.service.add_copy(self.actor, selected, data["barcode"], data["shelf"], data["price"]), "Copy added."):
                self.show_page("Books")
        def delete() -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select a book", "Select a book first.", parent=self.root)
            elif messagebox.askyesno("Delete book", "Delete this title and its copies?", parent=self.root):
                if self._run(lambda: self.service.delete_book(self.actor, selected), "Book deleted.") is not None:
                    self.show_page("Books")
        self._button(row, "Add book", lambda: form(), True).pack(side="left", padx=(0, 8))
        self._button(row, "Edit selected", edit).pack(side="left", padx=(0, 8))
        self._button(row, "Add copy", add_copy).pack(side="left", padx=(0, 8))
        self._button(row, "Delete selected", delete).pack(side="left")

    def _readers(self) -> None:
        card = self._card(self.page_area, 12)
        card.pack(fill="both", expand=True)
        self._reader_rows = {}
        rows = self.service.list_readers()
        table = self._table(card, [("card_number", "Card number", 130), ("full_name", "Reader", 190), ("reader_type", "Type", 90),
                                   ("status", "Status", 100), ("current_loans", "Loans", 70), ("expiry_date", "Expires", 110),
                                   ("email", "Email", 190)], rows, "reader_id", self._reader_rows)
        buttons = ttk.Frame(self.page_area, style="Canvas.TFrame")
        buttons.pack(fill="x", pady=(12, 0))
        def add_reader() -> None:
            fields = [("full_name", "Full name *", ""), ("username", "Login username *", ""), ("password", "Initial password (8+ chars) *", ""),
                      ("email", "Email", ""), ("phone", "Phone", ""), ("date_of_birth", "Date of birth (YYYY-MM-DD)", ""),
                      ("address", "Address", ""), ("reader_type", "Reader type", "Student", ["Student", "Teacher", "Other"]),
                      ("expiry_date", "Membership expiry (YYYY-MM-DD)", "")]
            data = self._form("Register reader", fields)
            if data is not None:
                card_number = self._run(lambda: self.service.create_reader(self.actor, data), "Reader registered.")
                if card_number:
                    messagebox.showinfo("Reader card", f"New card number: {card_number}", parent=self.root)
                    self.show_page("Readers")
        def change_status(status: str) -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select a reader", "Select a reader first.", parent=self.root)
                return
            expiry = None
            if status == "ACTIVE":
                expiry = self._form("Renew membership", [("expiry_date", "New expiry date (YYYY-MM-DD)", "")])
                if expiry is None:
                    return
                expiry = expiry["expiry_date"]
            if self._run(lambda: self.service.update_reader_status(self.actor, selected, status, expiry), "Reader updated.") is None:
                return
            self.show_page("Readers")
        self._button(buttons, "Add reader", add_reader, True).pack(side="left", padx=(0, 8))
        self._button(buttons, "Suspend card", lambda: change_status("SUSPENDED")).pack(side="left", padx=(0, 8))
        self._button(buttons, "Renew / activate card", lambda: change_status("ACTIVE")).pack(side="left")

    def _borrow(self) -> None:
        card = self._card(self.page_area, 22)
        card.pack(fill="x")
        tk.Label(card, text="01  Validate reader card", bg="white", fg=COLORS["teal"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 16))
        tk.Label(card, text="Reader card number", bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w")
        tk.Label(card, text="Copy barcode", bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).grid(row=1, column=1, sticky="w", padx=16)
        card_entry, barcode_entry = ttk.Entry(card, width=30), ttk.Entry(card, width=30)
        card_entry.grid(row=2, column=0, sticky="ew", pady=(5, 12))
        barcode_entry.grid(row=2, column=1, sticky="ew", padx=16, pady=(5, 12))
        card.columnconfigure(0, weight=1)
        card.columnconfigure(1, weight=1)
        summary = tk.Label(card, text="Enter a valid card number and a scanned barcode.", bg=COLORS["teal_light"], fg=COLORS["ink"], anchor="w", padx=12, pady=12, font=("Segoe UI", 10))
        summary.grid(row=3, column=0, columnspan=3, sticky="ew", pady=(4, 17))
        def checkout() -> None:
            result = self._run(lambda: self.service.checkout(self.actor, card_entry.get(), barcode_entry.get()))
            if result:
                summary.configure(text=f"Eligible  ·  {result['reader']}  ·  {result['title']}  ·  Due {result['due_date']}")
                barcode_entry.delete(0, "end")
                if messagebox.askyesno("Checkout complete", f"Loan created. Due date: {result['due_date']}\n\nPrint loan slip?", parent=self.root):
                    messagebox.showinfo("Loan slip", f"Northstar Library\nReader: {result['reader']}\nTitle: {result['title']}\nDue: {result['due_date']}", parent=self.root)
        ttk.Button(card, text="Confirm checkout", command=checkout, style="Accent.TButton").grid(row=4, column=0, sticky="w")
        ttk.Button(card, text="Clear", command=lambda: (card_entry.delete(0, "end"), barcode_entry.delete(0, "end"))).grid(row=4, column=1, sticky="w", padx=16)
        card_entry.focus_set()
        barcode_entry.bind("<Return>", lambda _event: checkout())
        recent = self._card(self.page_area, 14)
        recent.pack(fill="both", expand=True, pady=(17, 0))
        ttk.Label(recent, text="Current active loans", style="Header.TLabel").pack(anchor="w", pady=(0, 10))
        active = [loan for loan in self.service.list_loans() if loan["status"] in {"BORROWED", "OVERDUE"}]
        self._table(recent, [("card_number", "Card", 120), ("full_name", "Reader", 160), ("title", "Title", 220),
                             ("barcode", "Barcode", 120), ("due_date", "Due date", 110), ("status", "Status", 100)], active, "loan_id")

    def _return(self) -> None:
        card = self._card(self.page_area, 22)
        card.pack(fill="x")
        tk.Label(card, text="02  Locate active loan", bg="white", fg=COLORS["teal"], font=("Segoe UI", 12, "bold")).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 15))
        tk.Label(card, text="Copy barcode", bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).grid(row=1, column=0, sticky="w")
        barcode = ttk.Entry(card, width=28)
        barcode.grid(row=2, column=0, sticky="ew", pady=(5, 15))
        tk.Label(card, text="Condition", bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).grid(row=1, column=1, sticky="w", padx=12)
        condition = ttk.Combobox(card, values=["Good", "Damaged", "Lost"], state="readonly", width=17)
        condition.set("Good")
        condition.grid(row=2, column=1, sticky="ew", padx=12, pady=(5, 15))
        tk.Label(card, text="Compensation (VND)", bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).grid(row=1, column=2, sticky="w")
        compensation = ttk.Entry(card, width=20)
        compensation.insert(0, "0")
        compensation.grid(row=2, column=2, sticky="ew", pady=(5, 15))
        summary = tk.Label(card, text="Return details and late fine will be calculated automatically.", bg=COLORS["teal_light"], fg=COLORS["ink"], anchor="w", padx=12, pady=11)
        summary.grid(row=3, column=0, columnspan=4, sticky="ew", pady=(0, 15))
        def submit() -> None:
            result = self._run(lambda: self.service.return_copy(self.actor, barcode.get(), condition.get(), compensation.get()))
            if result:
                summary.configure(text=f"Returned: {result['title']}  ·  {result['reader']}  ·  Late fine: {result['late_fine']:,.0f} VND  ·  Copy: {result['copy_status']}")
                messagebox.showinfo("Return complete", summary.cget("text"), parent=self.root)
                barcode.delete(0, "end")
        ttk.Button(card, text="Confirm return", style="Accent.TButton", command=submit).grid(row=4, column=0, sticky="w")
        for col in range(3):
            card.columnconfigure(col, weight=1)
        barcode.bind("<Return>", lambda _event: submit())
        table_card = self._card(self.page_area, 14)
        table_card.pack(fill="both", expand=True, pady=(17, 0))
        active = [loan for loan in self.service.list_loans() if loan["status"] in {"BORROWED", "OVERDUE"}]
        self._table(table_card, [("barcode", "Barcode", 120), ("title", "Title", 220), ("full_name", "Reader", 160),
                                 ("loan_date", "Loan date", 110), ("due_date", "Due date", 110), ("status", "Status", 100)], active, "loan_id")

    def _reservations(self) -> None:
        card = self._card(self.page_area, 12)
        card.pack(fill="both", expand=True)
        self._reservation_rows = {}
        table = self._table(card, [("reservation_id", "ID", 55), ("title", "Title", 220), ("card_number", "Reader card", 120),
                                   ("full_name", "Reader", 150), ("reservation_date", "Requested", 105),
                                   ("expiry_date", "Pickup until", 110), ("status", "Status", 100)],
                            self.service.list_reservations(), "reservation_id", self._reservation_rows)
        buttons = ttk.Frame(self.page_area, style="Canvas.TFrame")
        buttons.pack(fill="x", pady=(12, 0))
        def cancel() -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select a reservation", "Select a reservation first.", parent=self.root)
                return
            if self._run(lambda: self.service.cancel_reservation(self.actor, selected), "Reservation cancelled.") is None:
                return
            self.show_page("Reservations")
        self._button(buttons, "Cancel selected", cancel).pack(side="left")
        self._button(buttons, "Refresh", lambda: self.show_page("Reservations")).pack(side="left", padx=8)

    def _fines(self) -> None:
        card = self._card(self.page_area, 12)
        card.pack(fill="both", expand=True)
        rows = self.service.list_fines(unpaid_only=True)
        table = self._table(card, [("fine_id", "Fine ID", 70), ("card_number", "Reader card", 125), ("full_name", "Reader", 150),
                                   ("title", "Title", 210), ("reason", "Reason", 95), ("amount", "Amount (VND)", 120),
                                   ("issued_date", "Issued", 110)], rows, "fine_id")
        row = ttk.Frame(self.page_area, style="Canvas.TFrame")
        row.pack(fill="x", pady=(12, 0))
        def pay() -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select a fine", "Select an unpaid fine first.", parent=self.root)
                return
            if messagebox.askyesno("Record payment", "Record full payment and issue a receipt?", parent=self.root):
                receipt = self._run(lambda: self.service.pay_fine(self.actor, selected))
                if receipt:
                    messagebox.showinfo("Payment receipt", f"Payment recorded. Receipt: {receipt}", parent=self.root)
                    self.show_page("Fines")
        self._button(row, "Record payment", pay, True).pack(side="left")
        self._button(row, "Refresh", lambda: self.show_page("Fines")).pack(side="left", padx=8)

    def _reports(self) -> None:
        bar = self._card(self.page_area, 14)
        bar.pack(fill="x", pady=(0, 14))
        tk.Label(bar, text="Report", bg="white", fg=COLORS["muted"]).pack(side="left")
        report_type = ttk.Combobox(bar, state="readonly", values=["Books borrowed per period", "Most borrowed titles", "Overdue loans", "Active readers", "Fine revenue", "Current inventory"], width=27)
        report_type.set("Books borrowed per period")
        report_type.pack(side="left", padx=(8, 12))
        tk.Label(bar, text="From", bg="white", fg=COLORS["muted"]).pack(side="left")
        start = ttk.Entry(bar, width=13)
        start.pack(side="left", padx=7)
        tk.Label(bar, text="To", bg="white", fg=COLORS["muted"]).pack(side="left")
        end = ttk.Entry(bar, width=13)
        end.pack(side="left", padx=7)
        results_card = self._card(self.page_area, 12)
        results_card.pack(fill="both", expand=True)
        state: dict[str, Any] = {"rows": []}
        def generate() -> None:
            rows = self._run(lambda: self.service.report(report_type.get(), start.get(), end.get()))
            if rows is None:
                return
            state["rows"] = rows
            for child in results_card.winfo_children():
                child.destroy()
            cols = list(rows[0].keys()) if rows else []
            if cols:
                self._table(results_card, [(key, key.replace("_", " ").title(), 150) for key in cols], rows, cols[0])
            else:
                tk.Label(results_card, text="No report rows for this selection.", bg="white", fg=COLORS["muted"]).pack(pady=25)
        def export() -> None:
            if not state["rows"]:
                messagebox.showwarning("No data", "Generate a report with data before exporting.", parent=self.root)
                return
            path = filedialog.asksaveasfilename(parent=self.root, defaultextension=".xlsx", filetypes=[("Excel workbook", "*.xlsx")])
            if path:
                self._run(lambda: export_xlsx(path, state["rows"]), "Excel report exported.")
        self._button(bar, "Generate report", generate, True).pack(side="left", padx=(8, 7))
        self._button(bar, "Export Excel", export).pack(side="left")
        generate()

    def _settings(self) -> None:
        if not self.actor or self.actor["role"] != "ADMIN":
            ttk.Label(self.page_area, text="Administrator access is required.", style="Sub.TLabel").pack(anchor="w")
            return
        sections = ttk.Frame(self.page_area, style="Canvas.TFrame")
        sections.pack(fill="both", expand=True)
        settings_card = self._card(sections, 18)
        settings_card.pack(fill="x", pady=(0, 15))
        ttk.Label(settings_card, text="Lending parameters", style="Header.TLabel").pack(anchor="w", pady=(0, 13))
        values = self.service.settings()
        labels = [("LOAN_DAYS", "Loan period (days)"), ("MAX_BOOKS", "Maximum books"), ("MAX_RENEWALS", "Maximum renewals"),
                  ("FINE_PER_DAY", "Fine per day (VND)"), ("HOLD_DAYS", "Reservation pickup days")]
        entries = {}
        form = ttk.Frame(settings_card, style="Card.TFrame")
        form.pack(fill="x")
        for index, (key, label) in enumerate(labels):
            col, row = index % 3, index // 3
            tk.Label(form, text=label, bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).grid(row=row * 2, column=col, sticky="w", padx=(0, 18), pady=(2, 4))
            entry = ttk.Entry(form, width=18)
            entry.insert(0, values.get(key, ""))
            entry.grid(row=row * 2 + 1, column=col, sticky="ew", padx=(0, 18), pady=(0, 10))
            entries[key] = entry
        for col in range(3):
            form.columnconfigure(col, weight=1)
        def save_settings() -> None:
            data = {key: entry.get() for key, entry in entries.items()}
            if self._run(lambda: self.service.update_settings(self.actor, data), "Library parameters saved.") is not None:
                self.show_page("Staff & settings")
        self._button(settings_card, "Save parameters", save_settings, True).pack(anchor="w", pady=(7, 0))
        accounts_card = self._card(sections, 12)
        accounts_card.pack(fill="both", expand=True)
        ttk.Label(accounts_card, text="Staff accounts", style="Header.TLabel").pack(anchor="w", pady=(0, 10))
        accounts = self.service.list_accounts()
        table = self._table(accounts_card, [("username", "Username", 130), ("full_name", "Name", 175), ("email", "Email", 180),
                                            ("role", "Role", 110), ("status", "Status", 100)], accounts, "account_id")
        buttons = ttk.Frame(self.page_area, style="Canvas.TFrame")
        buttons.pack(fill="x", pady=(10, 0))
        def create_staff() -> None:
            data = self._form("Add staff account", [("username", "Username *", ""), ("password", "Password (8+ chars) *", ""),
                                                    ("full_name", "Full name *", ""), ("email", "Email", ""),
                                                    ("role", "Role", "LIBRARIAN", ["LIBRARIAN", "ADMIN"])])
            if data is not None and self._run(lambda: self.service.create_staff_account(self.actor, data["username"], data["password"], data["full_name"], data["email"], data["role"]), "Staff account created."):
                self.show_page("Staff & settings")
        def toggle() -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select an account", "Select a staff account first.", parent=self.root)
                return
            row = next((item for item in accounts if item["account_id"] == selected), None)
            if row is None:
                return
            status = "LOCKED" if row["status"] == "ACTIVE" else "ACTIVE"
            if self._run(lambda: self.service.set_account_status(self.actor, selected, status), f"Account set to {status}.") is not None:
                self.show_page("Staff & settings")
        self._button(buttons, "Add staff account", create_staff, True).pack(side="left", padx=(0, 8))
        self._button(buttons, "Lock / unlock selected", toggle).pack(side="left")

    def _audit(self) -> None:
        card = self._card(self.page_area, 12)
        card.pack(fill="both", expand=True)
        self._table(card, [("created_at", "Time", 175), ("username", "User", 130), ("action", "Action", 150),
                           ("entity", "Record type", 135), ("entity_id", "Record ID", 130)], self.service.audit_log(), "entity_id")

    def _my_account(self) -> None:
        if not self.actor or not self.actor.get("reader_id"):
            ttk.Label(self.page_area, text="Reader account details are not linked to this login.", style="Sub.TLabel").pack(anchor="w")
            return
        account = self._run(lambda: self.service.reader_account(self.actor))
        if not account:
            return
        profile = account["profile"]
        loans = [loan for loan in account["loans"] if loan["status"] in {"BORROWED", "OVERDUE"}]
        panel = self._card(self.page_area, 15)
        panel.pack(fill="x", pady=(0, 13))
        tk.Label(panel, text=f"{profile['full_name']}   ·   Card {profile['card_number']}   ·   Membership {profile['status']} until {profile['expiry_date']}",
                 bg="white", fg=COLORS["ink"], font=("Segoe UI", 10, "bold")).pack(anchor="w")
        tk.Label(panel, text=f"Borrowing allowance: {profile['current_loans']} current loan(s)", bg="white", fg=COLORS["muted"]).pack(anchor="w", pady=(6, 0))
        loans_card = self._card(self.page_area, 12)
        loans_card.pack(fill="both", expand=True, pady=(0, 12))
        ttk.Label(loans_card, text="Current loans", style="Header.TLabel").pack(anchor="w", pady=(0, 9))
        table = self._table(loans_card, [("title", "Title", 230), ("barcode", "Barcode", 130), ("loan_date", "Borrowed", 110),
                                         ("due_date", "Due date", 110), ("renew_count", "Renewals", 80), ("status", "Status", 100)], loans, "loan_id")
        buttons = ttk.Frame(self.page_area, style="Canvas.TFrame")
        buttons.pack(fill="x", pady=(0, 12))
        def renew() -> None:
            selected = self._selected_id(table)
            if selected is None:
                messagebox.showwarning("Select a loan", "Select a loan to renew.", parent=self.root)
                return
            due = self._run(lambda: self.service.renew_loan(self.actor, selected))
            if due:
                messagebox.showinfo("Renewal complete", f"New due date: {due}", parent=self.root)
                self.show_page("My account")
        self._button(buttons, "Renew selected loan", renew, True).pack(side="left")
        reservations_card = self._card(self.page_area, 12)
        reservations_card.pack(fill="both", expand=True, pady=(0, 12))
        ttk.Label(reservations_card, text="Reservations", style="Header.TLabel").pack(anchor="w", pady=(0, 9))
        holds = account["reservations"]
        hold_table = self._table(reservations_card, [("title", "Title", 220), ("reservation_date", "Requested", 110),
                                                       ("expiry_date", "Pickup until", 110), ("status", "Status", 100)], holds, "reservation_id")
        def cancel_hold() -> None:
            selected = self._selected_id(hold_table)
            if selected is None:
                messagebox.showwarning("Select a reservation", "Select a reservation to cancel.", parent=self.root)
                return
            if self._run(lambda: self.service.cancel_reservation(self.actor, selected), "Reservation cancelled.") is not None:
                self.show_page("My account")
        self._button(reservations_card, "Cancel selected reservation", cancel_hold).pack(anchor="w", pady=(9, 0))
        fines_card = self._card(self.page_area, 12)
        fines_card.pack(fill="x")
        ttk.Label(fines_card, text="Fines", style="Header.TLabel").pack(anchor="w", pady=(0, 8))
        fines = account["fines"]
        if fines:
            for fine in fines:
                tk.Label(fines_card, text=f"{fine['reason']} · {fine['title']} · {fine['amount']:,.0f} VND · {fine['status']}", bg="white", fg=COLORS["ink"], anchor="w").pack(fill="x", pady=2)
        else:
            tk.Label(fines_card, text="No fines.", bg="white", fg=COLORS["muted"], anchor="w").pack(fill="x")

    def _form(self, title: str, fields: list[tuple]) -> dict[str, str] | None:
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.configure(bg="white")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        outer = ttk.Frame(dialog, style="Card.TFrame", padding=22)
        outer.pack(fill="both", expand=True)
        tk.Label(outer, text=title, bg="white", fg=COLORS["ink"], font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 14))
        variables: dict[str, Any] = {}
        for field in fields:
            key, label, initial = field[:3]
            choices = field[3] if len(field) > 3 else None
            tk.Label(outer, text=label, bg="white", fg=COLORS["muted"], font=("Segoe UI", 9)).pack(anchor="w", pady=(6, 2))
            if choices:
                widget = ttk.Combobox(outer, state="readonly", values=choices, width=43)
                widget.set(initial)
            else:
                widget = ttk.Entry(outer, width=46, show="•" if "password" in key else "")
                if initial not in (None, ""):
                    widget.insert(0, str(initial))
            widget.pack(fill="x")
            variables[key] = widget
        result: dict[str, str] | None = None
        def accept() -> None:
            nonlocal result
            result = {key: widget.get().strip() for key, widget in variables.items()}
            required_empty = any(label.endswith("*") and not result[key] for key, label, *_rest in fields)
            if required_empty:
                messagebox.showwarning("Required fields", "Complete all required fields marked with *.", parent=dialog)
                result = None
                return
            dialog.destroy()
        buttons = ttk.Frame(outer, style="Card.TFrame")
        buttons.pack(fill="x", pady=(18, 0))
        ttk.Button(buttons, text="Cancel", command=dialog.destroy).pack(side="right")
        ttk.Button(buttons, text="Save", command=accept, style="Accent.TButton").pack(side="right", padx=(0, 8))
        dialog.bind("<Return>", lambda _event: accept())
        self.root.wait_window(dialog)
        return result
