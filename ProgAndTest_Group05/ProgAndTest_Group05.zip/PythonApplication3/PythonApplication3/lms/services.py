"""Business rules for catalogue, readers, circulation, fines, and administration."""

from __future__ import annotations

import secrets
import sqlite3
from datetime import date, datetime, timedelta
from typing import Any

from .database import Database
from .security import hash_password, verify_password


class LibraryError(Exception):
    """An expected business-rule or validation failure suitable for display."""


class LibraryService:
    def __init__(self, database: Database):
        self.db = database

    @staticmethod
    def _row(row: sqlite3.Row | None) -> dict[str, Any] | None:
        return dict(row) if row is not None else None

    @staticmethod
    def _rows(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
        return [dict(row) for row in rows]

    @staticmethod
    def _require(actor: dict[str, Any] | None, *roles: str) -> None:
        role = actor.get("role") if actor else None
        allowed = set(roles)
        if "LIBRARIAN" in allowed:
            allowed.add("ADMIN")
        if role not in allowed:
            raise LibraryError("You do not have permission to perform this action.")

    @staticmethod
    def _audit(connection: sqlite3.Connection, actor: dict[str, Any] | None,
               action: str, entity: str, entity_id: Any = "") -> None:
        connection.execute(
            "INSERT INTO audit_log(account_id,action,entity,entity_id) VALUES(?,?,?,?)",
            (actor.get("account_id") if actor else None, action, entity, str(entity_id)),
        )

    @staticmethod
    def _setting(connection: sqlite3.Connection, key: str, default: int) -> int:
        row = connection.execute("SELECT setting_value FROM setting WHERE setting_key=?", (key,)).fetchone()
        return int(row[0]) if row else default

    def login(self, username: str, password: str) -> dict[str, Any]:
        if not username.strip() or not password:
            raise LibraryError("Enter both username and password.")
        result = None
        invalid_credentials = False
        with self.db.transaction() as connection:
            account = connection.execute(
                "SELECT * FROM account WHERE username=? COLLATE NOCASE", (username.strip(),)
            ).fetchone()
            invalid_credentials = (
                account is None or account["status"] != "ACTIVE"
                or not verify_password(password, account["password_hash"])
            )
            if invalid_credentials:
                if account is not None and account["status"] == "ACTIVE":
                    attempts = account["failed_attempts"] + 1
                    status = "LOCKED" if attempts >= 5 else "ACTIVE"
                    connection.execute("UPDATE account SET failed_attempts=?,status=? WHERE account_id=?",
                                       (attempts, status, account["account_id"]))
            else:
                connection.execute("UPDATE account SET failed_attempts=0 WHERE account_id=?", (account["account_id"],))
                result = dict(account)
                result.pop("password_hash", None)
                if result["role"] == "READER":
                    reader = connection.execute("SELECT * FROM reader WHERE account_id=?", (result["account_id"],)).fetchone()
                    if reader:
                        result["reader_id"] = reader["reader_id"]
                        result["card_number"] = reader["card_number"]
                self._audit(connection, result, "LOGIN", "ACCOUNT", result["account_id"])
        if invalid_credentials:
            raise LibraryError("Invalid credentials or account locked. Contact a librarian if access is blocked.")
        return result

    def logout(self, actor: dict[str, Any]) -> None:
        with self.db.transaction() as connection:
            self._audit(connection, actor, "LOGOUT", "ACCOUNT", actor["account_id"])

    def change_password(self, actor: dict[str, Any], old_password: str, new_password: str) -> None:
        with self.db.transaction() as connection:
            row = connection.execute("SELECT password_hash FROM account WHERE account_id=?", (actor["account_id"],)).fetchone()
            if row is None or not verify_password(old_password, row[0]):
                raise LibraryError("Current password is incorrect.")
            connection.execute("UPDATE account SET password_hash=? WHERE account_id=?",
                               (hash_password(new_password), actor["account_id"]))
            self._audit(connection, actor, "UPDATE", "ACCOUNT", actor["account_id"])

    def list_books(self, query: str = "", category: str = "", author: str = "", year: str = "") -> list[dict[str, Any]]:
        conditions, params = [], []
        if query.strip():
            term = f"%{query.strip()}%"
            conditions.append("(b.title LIKE ? OR b.authors LIKE ? OR b.isbn LIKE ? OR b.category LIKE ? OR b.publisher LIKE ?)")
            params.extend([term] * 5)
        if category:
            conditions.append("b.category LIKE ?")
            params.append(f"%{category}%")
        if author:
            conditions.append("b.authors LIKE ?")
            params.append(f"%{author}%")
        if year:
            try:
                year_number = int(year)
            except ValueError as exc:
                raise LibraryError("Publication year must be a number.") from exc
            conditions.append("b.publication_year=?")
            params.append(year_number)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        connection = self.db.connect()
        try:
            rows = connection.execute(
                f"""SELECT b.*, COUNT(c.copy_id) AS total_copies,
                    SUM(CASE WHEN c.status='AVAILABLE' THEN 1 ELSE 0 END) AS available_copies,
                    MIN(CASE WHEN c.status='AVAILABLE' THEN c.shelf_location END) AS shelf_location
                    FROM book b LEFT JOIN book_copy c ON c.book_id=b.book_id {where}
                    GROUP BY b.book_id ORDER BY b.title COLLATE NOCASE""", params
            ).fetchall()
            return self._rows(rows)
        finally:
            connection.close()

    def save_book(self, actor: dict[str, Any], data: dict[str, Any], book_id: int | None = None) -> int:
        self._require(actor, "LIBRARIAN")
        isbn, title = data.get("isbn", "").strip(), data.get("title", "").strip()
        if not isbn or not title:
            raise LibraryError("ISBN and title are required.")
        year = data.get("publication_year") or None
        pages = data.get("pages") or None
        try:
            year = int(year) if year else None
            pages = int(pages) if pages else None
        except (ValueError, TypeError) as exc:
            raise LibraryError("Publication year and page count must be numbers.") from exc
        fields = (isbn, title, data.get("authors", "").strip(), data.get("publisher", "").strip(),
                  year, data.get("category", "").strip(), data.get("language", "").strip(), pages,
                  data.get("description", "").strip())
        with self.db.transaction() as connection:
            if book_id:
                result = connection.execute(
                    "UPDATE book SET isbn=?,title=?,authors=?,publisher=?,publication_year=?,category=?,language=?,pages=?,description=? WHERE book_id=?",
                    (*fields, book_id),
                )
                if not result.rowcount:
                    raise LibraryError("Book not found.")
                entity_id, action = book_id, "UPDATE"
            else:
                cursor = connection.execute(
                    "INSERT INTO book(isbn,title,authors,publisher,publication_year,category,language,pages,description) VALUES(?,?,?,?,?,?,?,?,?)",
                    fields,
                )
                entity_id, action = cursor.lastrowid, "CREATE"
            self._audit(connection, actor, action, "BOOK", entity_id)
            return int(entity_id)

    def delete_book(self, actor: dict[str, Any], book_id: int) -> None:
        self._require(actor, "LIBRARIAN")
        with self.db.transaction() as connection:
            if connection.execute("SELECT 1 FROM loan l JOIN book_copy c USING(copy_id) WHERE c.book_id=? AND l.status IN ('BORROWED','OVERDUE')", (book_id,)).fetchone():
                raise LibraryError("A title with active loans cannot be deleted.")
            if connection.execute("SELECT 1 FROM book WHERE book_id=?", (book_id,)).fetchone() is None:
                raise LibraryError("Book not found.")
            connection.execute("DELETE FROM reservation WHERE book_id=? AND status IN ('WAITING','READY')", (book_id,))
            connection.execute("DELETE FROM book_copy WHERE book_id=?", (book_id,))
            connection.execute("DELETE FROM book WHERE book_id=?", (book_id,))
            self._audit(connection, actor, "DELETE", "BOOK", book_id)

    def add_copy(self, actor: dict[str, Any], book_id: int, barcode: str, shelf: str, price: float = 0) -> int:
        self._require(actor, "LIBRARIAN")
        if not barcode.strip():
            raise LibraryError("Barcode is required.")
        try:
            price = float(price)
        except (ValueError, TypeError) as exc:
            raise LibraryError("Price must be a number.") from exc
        if price < 0:
            raise LibraryError("Price cannot be negative.")
        with self.db.transaction() as connection:
            cursor = connection.execute(
                "INSERT INTO book_copy(book_id,barcode,shelf_location,price) VALUES(?,?,?,?)",
                (book_id, barcode.strip(), shelf.strip(), price),
            )
            self._audit(connection, actor, "CREATE", "BOOK_COPY", cursor.lastrowid)
            return int(cursor.lastrowid)

    def list_readers(self, query: str = "") -> list[dict[str, Any]]:
        connection = self.db.connect()
        try:
            term = f"%{query.strip()}%"
            return self._rows(connection.execute(
                """SELECT r.*, COUNT(CASE WHEN l.status IN ('BORROWED','OVERDUE') THEN 1 END) AS current_loans
                   FROM reader r LEFT JOIN loan l ON l.reader_id=r.reader_id
                   WHERE ?='' OR r.full_name LIKE ? OR r.card_number LIKE ? OR r.email LIKE ?
                   GROUP BY r.reader_id ORDER BY r.full_name COLLATE NOCASE""", (query.strip(), term, term, term)
            ).fetchall())
        finally:
            connection.close()

    def reader_account(self, actor: dict[str, Any]) -> dict[str, Any]:
        self._require(actor, "READER")
        reader_id = actor.get("reader_id")
        if not reader_id:
            raise LibraryError("No reader record is linked to this account.")
        connection = self.db.connect()
        try:
            profile = connection.execute(
                """SELECT r.*,COUNT(CASE WHEN l.status IN ('BORROWED','OVERDUE') THEN 1 END) AS current_loans
                   FROM reader r LEFT JOIN loan l ON l.reader_id=r.reader_id
                   WHERE r.reader_id=? AND r.account_id=? GROUP BY r.reader_id""",
                (reader_id, actor["account_id"]),
            ).fetchone()
            if profile is None:
                raise LibraryError("Reader record not found for this account.")
            loans = connection.execute(
                """SELECT l.*,b.title,b.isbn,c.barcode,c.shelf_location FROM loan l
                   JOIN book_copy c USING(copy_id) JOIN book b USING(book_id)
                   WHERE l.reader_id=? ORDER BY l.loan_date DESC,l.loan_id DESC""", (reader_id,)
            ).fetchall()
            reservations = connection.execute(
                """SELECT h.*,b.title,c.barcode FROM reservation h JOIN book b USING(book_id)
                   LEFT JOIN book_copy c USING(copy_id) WHERE h.reader_id=? ORDER BY h.reservation_date DESC""", (reader_id,)
            ).fetchall()
            fines = connection.execute(
                """SELECT f.*,b.title FROM fine f JOIN loan l USING(loan_id)
                   JOIN book_copy c USING(copy_id) JOIN book b USING(book_id)
                   WHERE l.reader_id=? ORDER BY f.issued_date DESC""", (reader_id,)
            ).fetchall()
            return {"profile": dict(profile), "loans": self._rows(loans),
                    "reservations": self._rows(reservations), "fines": self._rows(fines)}
        finally:
            connection.close()

    def create_reader(self, actor: dict[str, Any], data: dict[str, Any]) -> str:
        self._require(actor, "LIBRARIAN")
        name = data.get("full_name", "").strip()
        username = data.get("username", "").strip()
        if not name or not username:
            raise LibraryError("Reader name and login username are required.")
        password_hash = hash_password(data.get("password", ""))
        today = date.today()
        expiry = data.get("expiry_date") or (today + timedelta(days=365)).isoformat()
        try:
            date.fromisoformat(expiry)
        except ValueError as exc:
            raise LibraryError("Membership expiry must use YYYY-MM-DD.") from exc
        card = "R" + secrets.token_hex(4).upper()
        with self.db.transaction() as connection:
            account = connection.execute(
                "INSERT INTO account(username,password_hash,full_name,email,role) VALUES(?,?,?,?,?)",
                (username, password_hash, name, data.get("email", "").strip(), "READER"),
            )
            connection.execute(
                """INSERT INTO reader(account_id,card_number,full_name,date_of_birth,address,phone,email,reader_type,issue_date,expiry_date)
                   VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (account.lastrowid, card, name, data.get("date_of_birth", ""), data.get("address", "").strip(),
                 data.get("phone", "").strip(), data.get("email", "").strip(), data.get("reader_type", "Other"),
                 today.isoformat(), expiry),
            )
            reader_id = connection.execute("SELECT reader_id FROM reader WHERE card_number=?", (card,)).fetchone()[0]
            self._audit(connection, actor, "CREATE", "READER", reader_id)
            return card

    def update_reader_status(self, actor: dict[str, Any], reader_id: int, status: str, expiry_date: str | None = None) -> None:
        self._require(actor, "LIBRARIAN")
        if status not in {"ACTIVE", "SUSPENDED", "EXPIRED"}:
            raise LibraryError("Unsupported reader status.")
        if expiry_date:
            try:
                date.fromisoformat(expiry_date)
            except ValueError as exc:
                raise LibraryError("Membership expiry must use YYYY-MM-DD.") from exc
        with self.db.transaction() as connection:
            result = connection.execute(
                "UPDATE reader SET status=?,expiry_date=COALESCE(?,expiry_date) WHERE reader_id=?",
                (status, expiry_date, reader_id),
            )
            if not result.rowcount:
                raise LibraryError("Reader not found.")
            self._audit(connection, actor, "UPDATE", "READER", reader_id)

    def checkout(self, actor: dict[str, Any], card_number: str, barcode: str) -> dict[str, Any]:
        self._require(actor, "LIBRARIAN")
        today = date.today()
        with self.db.transaction() as connection:
            reader = connection.execute("SELECT * FROM reader WHERE card_number=?", (card_number.strip(),)).fetchone()
            if reader is None:
                raise LibraryError("Reader card was not found.")
            if reader["status"] != "ACTIVE" or date.fromisoformat(reader["expiry_date"]) < today:
                raise LibraryError("Reader card is expired or suspended.")
            active = connection.execute("SELECT COUNT(*) FROM loan WHERE reader_id=? AND status IN ('BORROWED','OVERDUE')", (reader["reader_id"],)).fetchone()[0]
            if active >= self._setting(connection, "MAX_BOOKS", 5):
                raise LibraryError("Reader has reached the maximum number of books.")
            if connection.execute("SELECT 1 FROM loan WHERE reader_id=? AND status='OVERDUE'", (reader["reader_id"],)).fetchone():
                raise LibraryError("Reader has an overdue book and cannot borrow.")
            if connection.execute("SELECT 1 FROM fine f JOIN loan l USING(loan_id) WHERE l.reader_id=? AND f.status='UNPAID'", (reader["reader_id"],)).fetchone():
                raise LibraryError("Reader has unpaid fines and cannot borrow.")
            copy = connection.execute(
                "SELECT c.*,b.title FROM book_copy c JOIN book b USING(book_id) WHERE c.barcode=?", (barcode.strip(),)
            ).fetchone()
            if copy is None or copy["status"] != "AVAILABLE":
                raise LibraryError("Copy is not available for checkout.")
            loan_days = self._setting(connection, "LOAN_DAYS", 14)
            due = today + timedelta(days=loan_days)
            cursor = connection.execute(
                "INSERT INTO loan(reader_id,copy_id,librarian_id,loan_date,due_date) VALUES(?,?,?,?,?)",
                (reader["reader_id"], copy["copy_id"], actor["account_id"], today.isoformat(), due.isoformat()),
            )
            connection.execute("UPDATE book_copy SET status='BORROWED' WHERE copy_id=?", (copy["copy_id"],))
            self._audit(connection, actor, "CHECKOUT", "LOAN", cursor.lastrowid)
            return {"loan_id": cursor.lastrowid, "title": copy["title"], "due_date": due.isoformat(), "reader": reader["full_name"]}

    def return_copy(self, actor: dict[str, Any], barcode: str, condition: str = "Good", compensation: float = 0) -> dict[str, Any]:
        self._require(actor, "LIBRARIAN")
        if condition not in {"Good", "Damaged", "Lost"}:
            raise LibraryError("Return condition must be Good, Damaged, or Lost.")
        if condition != "Good":
            try:
                compensation = float(compensation)
            except (TypeError, ValueError) as exc:
                raise LibraryError("Enter the compensation amount for a damaged or lost copy.") from exc
            if compensation <= 0:
                raise LibraryError("Compensation must be greater than zero.")
        today = date.today()
        with self.db.transaction() as connection:
            loan = connection.execute(
                """SELECT l.*,c.copy_id,c.book_id,c.barcode,b.title,r.reader_id,r.full_name
                   FROM loan l JOIN book_copy c USING(copy_id) JOIN book b USING(book_id)
                   JOIN reader r USING(reader_id)
                   WHERE c.barcode=? AND l.status IN ('BORROWED','OVERDUE')""", (barcode.strip(),)
            ).fetchone()
            if loan is None:
                raise LibraryError("No active loan was found for this barcode.")
            connection.execute("UPDATE loan SET status='RETURNED',return_date=?,return_condition=? WHERE loan_id=?",
                               (today.isoformat(), condition, loan["loan_id"]))
            late_days = max((today - date.fromisoformat(loan["due_date"])).days, 0)
            late_amount = late_days * self._setting(connection, "FINE_PER_DAY", 2000)
            if late_amount:
                connection.execute(
                    """INSERT INTO fine(loan_id,amount,reason,issued_date) VALUES(?,?,'LATE',?)
                       ON CONFLICT(loan_id,reason) DO UPDATE SET amount=excluded.amount""",
                    (loan["loan_id"], late_amount, today.isoformat()),
                )
            reason = {"Damaged": "DAMAGED", "Lost": "LOST"}.get(condition)
            if reason:
                connection.execute(
                    "INSERT INTO fine(loan_id,amount,reason,issued_date) VALUES(?,?,?,?) "
                    "ON CONFLICT(loan_id,reason) DO UPDATE SET amount=excluded.amount",
                    (loan["loan_id"], compensation, reason, today.isoformat()),
                )
            copy_status = "AVAILABLE" if condition == "Good" else condition.upper()
            ready_reservation = None
            if condition == "Good":
                ready_reservation = connection.execute(
                    "SELECT * FROM reservation WHERE book_id=? AND status='WAITING' ORDER BY reservation_date,reservation_id LIMIT 1",
                    (loan["book_id"],),
                ).fetchone()
                if ready_reservation:
                    hold_days = self._setting(connection, "HOLD_DAYS", 3)
                    expires = today + timedelta(days=hold_days)
                    connection.execute(
                        "UPDATE reservation SET status='READY',copy_id=?,expiry_date=? WHERE reservation_id=?",
                        (loan["copy_id"], expires.isoformat(), ready_reservation["reservation_id"]),
                    )
                    copy_status = "RESERVED"
                    connection.execute("INSERT INTO notification(reader_id,message) VALUES(?,?)",
                                       (ready_reservation["reader_id"], f"A copy of {loan['title']} is ready for pickup until {expires.isoformat()}."))
            connection.execute("UPDATE book_copy SET status=? WHERE copy_id=?", (copy_status, loan["copy_id"]))
            self._audit(connection, actor, "RETURN", "LOAN", loan["loan_id"])
            return {"title": loan["title"], "reader": loan["full_name"], "late_days": late_days,
                    "late_fine": late_amount, "condition": condition, "copy_status": copy_status}

    def renew_loan(self, actor: dict[str, Any], loan_id: int, reader_id: int | None = None) -> str:
        self._require(actor, "READER", "LIBRARIAN")
        with self.db.transaction() as connection:
            loan = connection.execute("SELECT l.*,c.book_id FROM loan l JOIN book_copy c USING(copy_id) WHERE loan_id=?", (loan_id,)).fetchone()
            if loan is None or loan["status"] not in {"BORROWED", "OVERDUE"}:
                raise LibraryError("Active loan not found.")
            if actor["role"] == "READER" and loan["reader_id"] != actor.get("reader_id"):
                raise LibraryError("Readers may renew only their own loans.")
            if reader_id is not None and loan["reader_id"] != reader_id:
                raise LibraryError("Loan does not belong to the selected reader.")
            if date.fromisoformat(loan["due_date"]) < date.today() or loan["status"] == "OVERDUE":
                raise LibraryError("Overdue loans cannot be renewed.")
            if loan["renew_count"] >= self._setting(connection, "MAX_RENEWALS", 2):
                raise LibraryError("Maximum number of renewals reached.")
            if connection.execute("SELECT 1 FROM reservation WHERE book_id=? AND status IN ('WAITING','READY')", (loan["book_id"],)).fetchone():
                raise LibraryError("Another reader is waiting for this title.")
            due = date.fromisoformat(loan["due_date"]) + timedelta(days=self._setting(connection, "LOAN_DAYS", 14))
            connection.execute("UPDATE loan SET due_date=?,renew_count=renew_count+1 WHERE loan_id=?", (due.isoformat(), loan_id))
            self._audit(connection, actor, "RENEW", "LOAN", loan_id)
            return due.isoformat()

    def reserve_book(self, actor: dict[str, Any], book_id: int, reader_id: int | None = None) -> int:
        self._require(actor, "READER", "LIBRARIAN")
        if actor["role"] == "READER":
            reader_id = actor.get("reader_id")
        if not reader_id:
            raise LibraryError("Select a reader for this reservation.")
        with self.db.transaction() as connection:
            reader = connection.execute("SELECT * FROM reader WHERE reader_id=?", (reader_id,)).fetchone()
            if reader is None or reader["status"] != "ACTIVE" or date.fromisoformat(reader["expiry_date"]) < date.today():
                raise LibraryError("Reader card is not active.")
            if connection.execute("SELECT 1 FROM book_copy WHERE book_id=? AND status='AVAILABLE'", (book_id,)).fetchone():
                raise LibraryError("This title has an available copy and cannot be reserved.")
            if connection.execute("SELECT 1 FROM reservation WHERE book_id=? AND reader_id=? AND status IN ('WAITING','READY')", (book_id, reader_id)).fetchone():
                raise LibraryError("Reader already has an active reservation for this title.")
            cursor = connection.execute("INSERT INTO reservation(reader_id,book_id,reservation_date) VALUES(?,?,?)",
                                        (reader_id, book_id, date.today().isoformat()))
            self._audit(connection, actor, "CREATE", "RESERVATION", cursor.lastrowid)
            return int(cursor.lastrowid)

    def list_reservations(self, reader_id: int | None = None) -> list[dict[str, Any]]:
        connection = self.db.connect()
        try:
            where, params = ("WHERE r.reader_id=?", (reader_id,)) if reader_id else ("", ())
            return self._rows(connection.execute(
                f"""SELECT h.*,b.title,r.full_name,r.card_number,c.barcode FROM reservation h
                    JOIN book b USING(book_id) JOIN reader r USING(reader_id)
                    LEFT JOIN book_copy c USING(copy_id) {where}
                    ORDER BY CASE h.status WHEN 'READY' THEN 0 WHEN 'WAITING' THEN 1 ELSE 2 END,h.reservation_date""", params
            ).fetchall())
        finally:
            connection.close()

    def cancel_reservation(self, actor: dict[str, Any], reservation_id: int) -> None:
        self._require(actor, "READER", "LIBRARIAN")
        with self.db.transaction() as connection:
            reservation = connection.execute("SELECT * FROM reservation WHERE reservation_id=?", (reservation_id,)).fetchone()
            if reservation is None or reservation["status"] not in {"WAITING", "READY"}:
                raise LibraryError("Active reservation not found.")
            if actor["role"] == "READER" and reservation["reader_id"] != actor.get("reader_id"):
                raise LibraryError("Readers may cancel only their own reservations.")
            connection.execute("UPDATE reservation SET status='CANCELLED' WHERE reservation_id=?", (reservation_id,))
            if reservation["copy_id"]:
                connection.execute("UPDATE book_copy SET status='AVAILABLE' WHERE copy_id=? AND status='RESERVED'", (reservation["copy_id"],))
                next_hold = connection.execute("SELECT * FROM reservation WHERE book_id=? AND status='WAITING' ORDER BY reservation_date,reservation_id LIMIT 1", (reservation["book_id"],)).fetchone()
                if next_hold:
                    expires = date.today() + timedelta(days=self._setting(connection, "HOLD_DAYS", 3))
                    connection.execute("UPDATE reservation SET status='READY',copy_id=?,expiry_date=? WHERE reservation_id=?",
                                       (reservation["copy_id"], expires.isoformat(), next_hold["reservation_id"]))
                    connection.execute("UPDATE book_copy SET status='RESERVED' WHERE copy_id=?", (reservation["copy_id"],))
                    connection.execute("INSERT INTO notification(reader_id,message) VALUES(?,?)",
                                       (next_hold["reader_id"], f"A reserved copy is ready until {expires.isoformat()}."))
            self._audit(connection, actor, "CANCEL", "RESERVATION", reservation_id)

    def list_loans(self, reader_id: int | None = None, status: str | None = None) -> list[dict[str, Any]]:
        conditions, params = [], []
        if reader_id is not None:
            conditions.append("l.reader_id=?")
            params.append(reader_id)
        if status:
            conditions.append("l.status=?")
            params.append(status)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        connection = self.db.connect()
        try:
            return self._rows(connection.execute(
                f"""SELECT l.*,r.full_name,r.card_number,b.title,b.isbn,c.barcode,c.shelf_location
                    FROM loan l JOIN reader r USING(reader_id) JOIN book_copy c USING(copy_id)
                    JOIN book b USING(book_id) {where} ORDER BY l.loan_date DESC,l.loan_id DESC""", params
            ).fetchall())
        finally:
            connection.close()

    def list_fines(self, unpaid_only: bool = False, reader_id: int | None = None) -> list[dict[str, Any]]:
        conditions, params = [], []
        if unpaid_only:
            conditions.append("f.status='UNPAID'")
        if reader_id is not None:
            conditions.append("l.reader_id=?")
            params.append(reader_id)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        connection = self.db.connect()
        try:
            return self._rows(connection.execute(
                f"""SELECT f.*,l.reader_id,r.full_name,r.card_number,b.title,c.barcode
                    FROM fine f JOIN loan l USING(loan_id) JOIN reader r USING(reader_id)
                    JOIN book_copy c USING(copy_id) JOIN book b USING(book_id) {where}
                    ORDER BY f.status,f.issued_date DESC""", params
            ).fetchall())
        finally:
            connection.close()

    def pay_fine(self, actor: dict[str, Any], fine_id: int) -> str:
        self._require(actor, "LIBRARIAN")
        with self.db.transaction() as connection:
            fine = connection.execute("SELECT * FROM fine WHERE fine_id=?", (fine_id,)).fetchone()
            if fine is None or fine["status"] != "UNPAID":
                raise LibraryError("Unpaid fine not found.")
            receipt = f"RC-{datetime.now():%Y%m%d}-{secrets.token_hex(3).upper()}"
            connection.execute("UPDATE fine SET status='PAID',paid_date=?,receipt_no=? WHERE fine_id=?",
                               (date.today().isoformat(), receipt, fine_id))
            self._audit(connection, actor, "PAYMENT", "FINE", fine_id)
            return receipt

    def dashboard(self) -> dict[str, Any]:
        connection = self.db.connect()
        try:
            today = date.today().isoformat()
            stats = {
                "borrowed_today": connection.execute("SELECT COUNT(*) FROM loan WHERE loan_date=?", (today,)).fetchone()[0],
                "overdue": connection.execute("SELECT COUNT(*) FROM loan WHERE status='OVERDUE'").fetchone()[0],
                "new_readers": connection.execute("SELECT COUNT(*) FROM reader WHERE issue_date=?", (today,)).fetchone()[0],
                "unpaid_fines": connection.execute("SELECT COALESCE(SUM(amount),0) FROM fine WHERE status='UNPAID'").fetchone()[0],
                "inventory": connection.execute("SELECT COUNT(*) FROM book_copy").fetchone()[0],
                "active_readers": connection.execute("SELECT COUNT(*) FROM reader WHERE status='ACTIVE' AND expiry_date>=?", (today,)).fetchone()[0],
            }
            stats["recent_loans"] = self._rows(connection.execute(
                """SELECT l.loan_date,l.due_date,l.status,r.full_name,b.title,c.barcode
                   FROM loan l JOIN reader r USING(reader_id) JOIN book_copy c USING(copy_id)
                   JOIN book b USING(book_id) ORDER BY l.loan_id DESC LIMIT 8"""
            ).fetchall())
            return stats
        finally:
            connection.close()

    def report(self, report_type: str, start_date: str = "", end_date: str = "") -> list[dict[str, Any]]:
        try:
            start_value = date.fromisoformat(start_date) if start_date else None
            end_value = date.fromisoformat(end_date) if end_date else None
        except ValueError as exc:
            raise LibraryError("Report dates must use YYYY-MM-DD.") from exc
        if start_value and end_value and start_value > end_value:
            raise LibraryError("Report start date must not be after the end date.")
        start = start_date or "0001-01-01"
        end = end_date or "9999-12-31"
        connection = self.db.connect()
        try:
            if report_type == "Most borrowed titles":
                sql = """SELECT b.title,b.isbn,COUNT(l.loan_id) AS total_borrowed FROM book b
                         LEFT JOIN book_copy c USING(book_id)
                         LEFT JOIN loan l ON l.copy_id=c.copy_id AND l.loan_date BETWEEN ? AND ?
                         GROUP BY b.book_id ORDER BY total_borrowed DESC,b.title LIMIT 50"""
                params = (start, end)
            elif report_type == "Overdue loans":
                sql = """SELECT r.card_number,r.full_name,b.title,c.barcode,l.due_date
                         FROM loan l JOIN reader r USING(reader_id) JOIN book_copy c USING(copy_id)
                         JOIN book b USING(book_id) WHERE l.status='OVERDUE' ORDER BY l.due_date"""
                params = ()
            elif report_type == "Active readers":
                sql = "SELECT card_number,full_name,email,reader_type,expiry_date FROM reader WHERE status='ACTIVE' ORDER BY full_name"
                params = ()
            elif report_type == "Fine revenue":
                sql = "SELECT paid_date,COUNT(*) AS payments,SUM(amount) AS revenue FROM fine WHERE status='PAID' AND paid_date BETWEEN ? AND ? GROUP BY paid_date ORDER BY paid_date"
                params = (start, end)
            elif report_type == "Current inventory":
                sql = "SELECT b.isbn,b.title,c.barcode,c.shelf_location,c.status FROM book_copy c JOIN book b USING(book_id) ORDER BY b.title,c.barcode"
                params = ()
            else:
                sql = """SELECT l.loan_date,b.title,b.isbn,r.card_number,r.full_name,c.barcode,l.status
                         FROM loan l JOIN reader r USING(reader_id) JOIN book_copy c USING(copy_id)
                         JOIN book b USING(book_id) WHERE l.loan_date BETWEEN ? AND ? ORDER BY l.loan_date DESC"""
                params = (start, end)
            return self._rows(connection.execute(sql, params).fetchall())
        finally:
            connection.close()

    def settings(self) -> dict[str, str]:
        connection = self.db.connect()
        try:
            return {row["setting_key"]: row["setting_value"] for row in connection.execute("SELECT * FROM setting")}
        finally:
            connection.close()

    def update_settings(self, actor: dict[str, Any], settings: dict[str, str]) -> None:
        self._require(actor, "ADMIN")
        allowed = {"LOAN_DAYS", "MAX_BOOKS", "MAX_RENEWALS", "FINE_PER_DAY", "HOLD_DAYS"}
        if not settings or not set(settings).issubset(allowed):
            raise LibraryError("One or more library settings are invalid.")
        normalized = {}
        for key, value in settings.items():
            try:
                number = int(value)
            except (TypeError, ValueError) as exc:
                raise LibraryError(f"{key} must be a whole number.") from exc
            if number <= 0:
                raise LibraryError(f"{key} must be greater than zero.")
            normalized[key] = str(number)
        with self.db.transaction() as connection:
            connection.executemany("INSERT INTO setting(setting_key,setting_value) VALUES(?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",
                                   normalized.items())
            self._audit(connection, actor, "UPDATE", "SETTING", ",".join(normalized))

    def list_accounts(self) -> list[dict[str, Any]]:
        connection = self.db.connect()
        try:
            return self._rows(connection.execute("SELECT account_id,username,full_name,email,role,status,created_at FROM account ORDER BY role,username").fetchall())
        finally:
            connection.close()

    def create_staff_account(self, actor: dict[str, Any], username: str, password: str,
                             full_name: str, email: str, role: str) -> int:
        self._require(actor, "ADMIN")
        if role not in {"LIBRARIAN", "ADMIN"} or not username.strip() or not full_name.strip():
            raise LibraryError("Enter a username, name, and valid staff role.")
        with self.db.transaction() as connection:
            cursor = connection.execute("INSERT INTO account(username,password_hash,full_name,email,role) VALUES(?,?,?,?,?)",
                                        (username.strip(), hash_password(password), full_name.strip(), email.strip(), role))
            self._audit(connection, actor, "CREATE", "ACCOUNT", cursor.lastrowid)
            return int(cursor.lastrowid)

    def set_account_status(self, actor: dict[str, Any], account_id: int, status: str) -> None:
        self._require(actor, "ADMIN")
        if status not in {"ACTIVE", "LOCKED"}:
            raise LibraryError("Unsupported account status.")
        if account_id == actor["account_id"] and status == "LOCKED":
            raise LibraryError("You cannot lock your own active account.")
        with self.db.transaction() as connection:
            result = connection.execute("UPDATE account SET status=?,failed_attempts=0 WHERE account_id=?", (status, account_id))
            if not result.rowcount:
                raise LibraryError("Account not found.")
            self._audit(connection, actor, "UPDATE", "ACCOUNT", account_id)

    def audit_log(self) -> list[dict[str, Any]]:
        connection = self.db.connect()
        try:
            return self._rows(connection.execute(
                """SELECT a.created_at,a.username,l.action,l.entity,l.entity_id FROM audit_log l
                   LEFT JOIN account a USING(account_id) ORDER BY l.log_id DESC LIMIT 500"""
            ).fetchall())
        finally:
            connection.close()

    def run_daily_maintenance(self, actor: dict[str, Any] | None = None) -> dict[str, int]:
        today = date.today()
        with self.db.transaction() as connection:
            overdue = connection.execute("UPDATE loan SET status='OVERDUE' WHERE status='BORROWED' AND due_date<?", (today.isoformat(),)).rowcount
            rate = self._setting(connection, "FINE_PER_DAY", 2000)
            loans = connection.execute("SELECT loan_id,due_date FROM loan WHERE status='OVERDUE'").fetchall()
            for loan in loans:
                amount = max((today - date.fromisoformat(loan["due_date"])).days, 0) * rate
                if amount:
                    connection.execute(
                        """INSERT INTO fine(loan_id,amount,reason,issued_date) VALUES(?,?,'LATE',?)
                           ON CONFLICT(loan_id,reason) DO UPDATE SET amount=MAX(fine.amount,excluded.amount)""",
                        (loan["loan_id"], amount, today.isoformat()),
                    )
            expired_holds = connection.execute("SELECT * FROM reservation WHERE status='READY' AND expiry_date<?", (today.isoformat(),)).fetchall()
            for hold in expired_holds:
                connection.execute("UPDATE reservation SET status='EXPIRED' WHERE reservation_id=?", (hold["reservation_id"],))
                if hold["copy_id"]:
                    connection.execute("UPDATE book_copy SET status='AVAILABLE' WHERE copy_id=?", (hold["copy_id"],))
                    next_hold = connection.execute("SELECT * FROM reservation WHERE book_id=? AND status='WAITING' ORDER BY reservation_date,reservation_id LIMIT 1", (hold["book_id"],)).fetchone()
                    if next_hold:
                        expires = today + timedelta(days=self._setting(connection, "HOLD_DAYS", 3))
                        connection.execute("UPDATE reservation SET status='READY',copy_id=?,expiry_date=? WHERE reservation_id=?",
                                           (hold["copy_id"], expires.isoformat(), next_hold["reservation_id"]))
                        connection.execute("UPDATE book_copy SET status='RESERVED' WHERE copy_id=?", (hold["copy_id"],))
                        connection.execute("INSERT INTO notification(reader_id,message) VALUES(?,?)",
                                           (next_hold["reader_id"], f"A reserved copy is ready until {expires.isoformat()}."))
            expired_cards = connection.execute("UPDATE reader SET status='EXPIRED' WHERE status='ACTIVE' AND expiry_date<?", (today.isoformat(),)).rowcount
            self._audit(connection, actor, "DAILY_MAINTENANCE", "SYSTEM", today.isoformat())
            return {"overdue_loans": overdue, "expired_reservations": len(expired_holds), "expired_cards": expired_cards}
