"""SQLite database setup and transaction management."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import date, timedelta
from pathlib import Path
from typing import Iterator

from .security import hash_password


SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS account (
    account_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL DEFAULT '',
    role TEXT NOT NULL CHECK (role IN ('READER', 'LIBRARIAN', 'ADMIN')),
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'LOCKED')),
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reader (
    reader_id INTEGER PRIMARY KEY,
    account_id INTEGER UNIQUE REFERENCES account(account_id) ON DELETE SET NULL,
    card_number TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    date_of_birth TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL DEFAULT '',
    phone TEXT NOT NULL DEFAULT '',
    email TEXT NOT NULL DEFAULT '',
    reader_type TEXT NOT NULL DEFAULT 'Other' CHECK (reader_type IN ('Student', 'Teacher', 'Other')),
    issue_date TEXT NOT NULL,
    expiry_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'SUSPENDED', 'EXPIRED'))
);
CREATE TABLE IF NOT EXISTS book (
    book_id INTEGER PRIMARY KEY,
    isbn TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    authors TEXT NOT NULL DEFAULT '',
    publisher TEXT NOT NULL DEFAULT '',
    publication_year INTEGER,
    category TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT '',
    pages INTEGER,
    description TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS book_copy (
    copy_id INTEGER PRIMARY KEY,
    book_id INTEGER NOT NULL REFERENCES book(book_id) ON DELETE RESTRICT,
    barcode TEXT NOT NULL UNIQUE,
    shelf_location TEXT NOT NULL DEFAULT '',
    price REAL NOT NULL DEFAULT 0 CHECK (price >= 0),
    status TEXT NOT NULL DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE', 'BORROWED', 'RESERVED', 'LOST', 'DAMAGED'))
);
CREATE TABLE IF NOT EXISTS loan (
    loan_id INTEGER PRIMARY KEY,
    reader_id INTEGER NOT NULL REFERENCES reader(reader_id) ON DELETE RESTRICT,
    copy_id INTEGER NOT NULL REFERENCES book_copy(copy_id) ON DELETE RESTRICT,
    librarian_id INTEGER NOT NULL REFERENCES account(account_id),
    loan_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    return_date TEXT,
    return_condition TEXT,
    renew_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'BORROWED' CHECK (status IN ('BORROWED', 'RETURNED', 'OVERDUE'))
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_open_loan_copy ON loan(copy_id) WHERE status IN ('BORROWED', 'OVERDUE');
CREATE TABLE IF NOT EXISTS reservation (
    reservation_id INTEGER PRIMARY KEY,
    reader_id INTEGER NOT NULL REFERENCES reader(reader_id) ON DELETE RESTRICT,
    book_id INTEGER NOT NULL REFERENCES book(book_id) ON DELETE RESTRICT,
    copy_id INTEGER REFERENCES book_copy(copy_id) ON DELETE SET NULL,
    reservation_date TEXT NOT NULL,
    expiry_date TEXT,
    status TEXT NOT NULL DEFAULT 'WAITING' CHECK (status IN ('WAITING', 'READY', 'FULFILLED', 'CANCELLED', 'EXPIRED'))
);
CREATE TABLE IF NOT EXISTS fine (
    fine_id INTEGER PRIMARY KEY,
    loan_id INTEGER NOT NULL REFERENCES loan(loan_id) ON DELETE RESTRICT,
    amount REAL NOT NULL CHECK (amount >= 0),
    reason TEXT NOT NULL CHECK (reason IN ('LATE', 'LOST', 'DAMAGED')),
    issued_date TEXT NOT NULL,
    paid_date TEXT,
    receipt_no TEXT UNIQUE,
    status TEXT NOT NULL DEFAULT 'UNPAID' CHECK (status IN ('UNPAID', 'PAID')),
    UNIQUE (loan_id, reason)
);
CREATE TABLE IF NOT EXISTS setting (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
    log_id INTEGER PRIMARY KEY,
    account_id INTEGER REFERENCES account(account_id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_id TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS notification (
    notification_id INTEGER PRIMARY KEY,
    reader_id INTEGER NOT NULL REFERENCES reader(reader_id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'QUEUED',
    sent_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_book_title ON book(title);
CREATE INDEX IF NOT EXISTS ix_loan_reader_status ON loan(reader_id, status);
CREATE INDEX IF NOT EXISTS ix_reservation_queue ON reservation(book_id, status, reservation_date);
"""


class Database:
    """Creates independent SQLite connections and atomic write transactions."""

    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        if self.path != ":memory:":
            connection.execute("PRAGMA journal_mode = WAL")
        return connection

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        connection = self.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def initialize(self, seed_demo: bool = True) -> None:
        connection = self.connect()
        try:
            connection.executescript(SCHEMA)
            if seed_demo:
                self._seed(connection)
            connection.commit()
        finally:
            connection.close()

    @staticmethod
    def _seed(connection: sqlite3.Connection) -> None:
        accounts = connection.execute("SELECT COUNT(*) FROM account").fetchone()[0]
        if accounts:
            return
        credentials = (
            ("admin", "Admin123!", "Library Administrator", "ADMIN"),
            ("librarian", "Librarian123!", "Linh Nguyen", "LIBRARIAN"),
            ("reader", "Reader123!", "Minh Tran", "READER"),
        )
        account_ids = {}
        for username, password, full_name, role in credentials:
            cursor = connection.execute(
                "INSERT INTO account(username,password_hash,full_name,role) VALUES(?,?,?,?)",
                (username, hash_password(password), full_name, role),
            )
            account_ids[username] = cursor.lastrowid
        today = date.today()
        reader_cursor = connection.execute(
            """INSERT INTO reader(account_id,card_number,full_name,email,reader_type,issue_date,expiry_date)
               VALUES(?,?,?,?,?,?,?)""",
            (account_ids["reader"], "R00000001", "Minh Tran", "minh@example.test", "Student",
             today.isoformat(), (today + timedelta(days=365)).isoformat()),
        )
        connection.execute(
            "INSERT INTO book(isbn,title,authors,publisher,publication_year,category,language,pages,description) VALUES(?,?,?,?,?,?,?,?,?)",
            ("9780132350884", "Clean Code", "Robert C. Martin", "Prentice Hall", 2008,
             "Software Engineering", "English", 464, "A handbook of agile software craftsmanship."),
        )
        book_id = connection.execute("SELECT book_id FROM book WHERE isbn=?", ("9780132350884",)).fetchone()[0]
        connection.execute(
            "INSERT INTO book_copy(book_id,barcode,shelf_location,price) VALUES(?,?,?,?)",
            (book_id, "BC000001", "A-01-01", 35.0),
        )
        for key, value in (("LOAN_DAYS", "14"), ("MAX_BOOKS", "5"), ("MAX_RENEWALS", "2"),
                           ("FINE_PER_DAY", "2000"), ("HOLD_DAYS", "3")):
            connection.execute("INSERT INTO setting(setting_key,setting_value) VALUES(?,?)", (key, value))
        connection.execute(
            "INSERT INTO audit_log(account_id,action,entity,entity_id) VALUES(?,?,?,?)",
            (account_ids["admin"], "SEED", "SYSTEM", str(reader_cursor.lastrowid)),
        )
